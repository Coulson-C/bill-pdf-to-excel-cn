#!/usr/bin/env python3
"""国内银行流水 PDF（文本层）→ Excel/CSV。

首发支持（包内合成样例可跑通；真实网银导出版式可能需微调）：
  - icbc_like  工商银行
  - ccb_like   建设银行
  - cmb_like   招商银行

不做：扫描件 OCR、支付宝/微信账单、电子发票、电子回单验真。
"""
from __future__ import annotations

import argparse
import csv
import re
import sys
from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Font
from pypdf import PdfReader

FIELDNAMES = [
    "交易日期",
    "交易时间",
    "摘要",
    "借方金额",
    "贷方金额",
    "余额",
    "对方信息",
    "版式",
    "来源文件",
    "备注",
]


@dataclass
class Result:
    layout: str
    rows: list[dict]
    notes: list[str] = field(default_factory=list)


def pdf_text(path: Path) -> str:
    reader = PdfReader(str(path))
    return "\n".join((page.extract_text() or "") for page in reader.pages)


def detect_layout(text: str) -> str:
    if "中国工商银行" in text or ("借方金额" in text and "贷方金额" in text and "对方户名" in text):
        return "icbc_like"
    if "中国建设银行" in text or ("记账日" in text and "账户余额" in text):
        return "ccb_like"
    if "招商银行" in text or ("联机余额" in text and "交易类型" in text):
        return "cmb_like"
    raise ValueError(
        "未能识别银行版式。当前支持：工行/建行/招行文本层流水。"
        "扫描件请换网银导出可选中文字的 PDF；支付宝/微信/发票请购对应商品。"
    )


def _dec(s: str) -> str:
    s = (s or "").strip().replace(",", "")
    if not s or s == "-":
        return ""
    try:
        return f"{Decimal(s):.2f}"
    except InvalidOperation:
        return s


def _row(date, time, desc, debit, credit, bal, cp, layout, source, note="") -> dict:
    return {
        "交易日期": date,
        "交易时间": time,
        "摘要": desc,
        "借方金额": _dec(debit),
        "贷方金额": _dec(credit),
        "余额": _dec(bal),
        "对方信息": cp,
        "版式": layout,
        "来源文件": source,
        "备注": note,
    }


def parse_icbc(text: str, source: str) -> Result:
    """Line: YYYY-MM-DD 摘要 借方| -  贷方| -  余额 对方?"""
    rows = []
    rx = re.compile(
        r"^(?P<date>\d{4}-\d{2}-\d{2})\s+"
        r"(?P<desc>.+?)\s+"
        r"(?P<debit>-|\d+\.\d{2})\s+"
        r"(?P<credit>-|\d+\.\d{2})\s+"
        r"(?P<bal>\d+\.\d{2})"
        r"(?:\s+(?P<cp>.+))?\s*$"
    )
    for line in text.splitlines():
        line = line.strip()
        m = rx.match(line)
        if not m:
            continue
        rows.append(
            _row(
                m.group("date"),
                "",
                m.group("desc").strip(),
                m.group("debit"),
                m.group("credit"),
                m.group("bal"),
                (m.group("cp") or "").strip(),
                "icbc_like",
                source,
            )
        )
    return Result("icbc_like", rows, [] if rows else ["工行版式未解析到交易行"])


def parse_ccb(text: str, source: str) -> Result:
    """Line: YYYYMMDD 摘要 支出|- 收入|- 余额 对方?"""
    rows = []
    rx = re.compile(
        r"^(?P<date>\d{8})\s+"
        r"(?P<desc>.+?)\s+"
        r"(?P<out>-|\d+\.\d{2})\s+"
        r"(?P<inc>-|\d+\.\d{2})\s+"
        r"(?P<bal>\d+\.\d{2})"
        r"(?:\s+(?P<cp>.+))?\s*$"
    )
    for line in text.splitlines():
        line = line.strip()
        m = rx.match(line)
        if not m:
            continue
        d = m.group("date")
        date = f"{d[:4]}-{d[4:6]}-{d[6:8]}"
        rows.append(
            _row(
                date,
                "",
                m.group("desc").strip(),
                m.group("out"),
                m.group("inc"),
                m.group("bal"),
                (m.group("cp") or "").strip(),
                "ccb_like",
                source,
            )
        )
    return Result("ccb_like", rows, [] if rows else ["建行版式未解析到交易行"])


def parse_cmb(text: str, source: str) -> Result:
    rows = []
    rx = re.compile(
        r"^(?P<date>\d{4}-\d{2}-\d{2})\s+"
        r"(?P<time>\d{2}:\d{2}:\d{2})\s+"
        r"(?P<typ>\S+)\s+"
        r"(?P<amt>[+-]?\d+\.\d{2})\s+"
        r"(?P<bal>\d+\.\d{2})"
        r"(?:\s+(?P<note>.+))?\s*$"
    )
    for line in text.splitlines():
        line = line.strip()
        m = rx.match(line)
        if not m:
            continue
        amt = Decimal(m.group("amt"))
        typ = m.group("typ")
        note = (m.group("note") or "").strip()
        if amt < 0 or typ in ("消费", "转出", "取现"):
            debit, credit = str(abs(amt)), ""
        else:
            debit, credit = "", str(abs(amt))
        desc = typ if not note else f"{typ} {note}"
        rows.append(
            _row(m.group("date"), m.group("time"), desc, debit, credit, m.group("bal"), "", "cmb_like", source, note)
        )
    return Result("cmb_like", rows, [] if rows else ["招行版式未解析到交易行"])


PARSERS = {"icbc_like": parse_icbc, "ccb_like": parse_ccb, "cmb_like": parse_cmb}


def extract(path: Path) -> Result:
    text = pdf_text(path)
    if not text.strip():
        raise ValueError(
            "无提取到文字：可能是扫描件/纯图 PDF。本包不支持 OCR。"
            "请从网银/手机银行重新导出「可选中文字」的明细 PDF。"
        )
    layout = detect_layout(text)
    return PARSERS[layout](text, path.name)


def write_xlsx(rows: list[dict], out: Path, notes: list[str] | None = None) -> None:
    wb = Workbook()
    ws = wb.active
    ws.title = "流水明细"
    ws.append(FIELDNAMES)
    for c in ws[1]:
        c.font = Font(bold=True)
    for r in rows:
        ws.append([r.get(h, "") for h in FIELDNAMES])
    ws2 = wb.create_sheet("说明")
    ws2.append(["项", "内容"])
    ws2.append(["行数", len(rows)])
    for n in notes or []:
        ws2.append(["备注", n])
    out.parent.mkdir(parents=True, exist_ok=True)
    wb.save(out)


def write_csv(rows: list[dict], out: Path) -> None:
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=FIELDNAMES)
        w.writeheader()
        for r in rows:
            w.writerow({h: r.get(h, "") for h in FIELDNAMES})


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="国内银行流水 PDF → Excel（工行/建行/招行文本层）")
    ap.add_argument("inputs", nargs="+", help="PDF 文件或文件夹")
    ap.add_argument("-o", "--output", default="out/银行流水.xlsx")
    ap.add_argument("--csv", dest="csv_out", default="")
    args = ap.parse_args(argv)

    files: list[Path] = []
    for p in map(Path, args.inputs):
        if p.is_dir():
            files.extend(sorted({*p.glob("*.pdf"), *p.glob("*.PDF")}))
        else:
            files.append(p)
    # skip scan demo unless alone
    files = [f for f in files if "scan" not in f.name.lower()] or files
    if not files:
        print("未找到 PDF", file=sys.stderr)
        return 2

    all_rows: list[dict] = []
    all_notes: list[str] = []
    errors = 0
    for f in files:
        try:
            res = extract(f)
            all_rows.extend(res.rows)
            all_notes.append(f"{f.name}: layout={res.layout}, rows={len(res.rows)}")
            all_notes.extend(res.notes)
            print(f"OK {f.name}: {res.layout} → {len(res.rows)} 行")
            if not res.rows:
                errors += 1
        except Exception as e:
            errors += 1
            all_notes.append(f"FAIL {f.name}: {e}")
            print(f"FAIL {f.name}: {e}", file=sys.stderr)

    out = Path(args.output)
    write_xlsx(all_rows, out, all_notes)
    if args.csv_out:
        write_csv(all_rows, Path(args.csv_out))
    print(f"写出 {len(all_rows)} 行 → {out}")
    return 0 if errors == 0 and all_rows else 1


if __name__ == "__main__":
    raise SystemExit(main())
