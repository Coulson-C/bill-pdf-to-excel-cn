# 银行流水 PDF → Excel 本地包（工行 / 建行 / 招行）

把网银或手机银行导出的**可选中文字**的交易明细 PDF，在本地整理成 Excel / CSV。  
**不上传。不做扫描 OCR。不是发票工具。不是支付宝/微信账单包。**

版本：burn-night-2026-10-31 · 正式可运行包（替代预售占位包）

---

## 你能得到什么

| 内容 | 说明 |
|------|------|
| `extract_cn_bank.py` | 主程序 |
| `requirements.txt` | 依赖 |
| `一键演示.sh` / `一键演示.bat` | 跑通样例 |
| `samples/` | 工行/建行/招行**虚构**流水 PDF + 扫描件对照（应失败） |
| `expected/expected_from_synth.csv` | 样例期望输出 |
| `scripts/generate_cn_samples.py` | 重新生成演示 PDF（可选） |
| `支持银行与字段.md` | 字段与边界 |

---

## 环境

- Python **3.10+**
- 文本层 PDF（阅读器里能选中、复制文字）

---

## 安装与演示

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python extract_cn_bank.py samples -o out/银行流水.xlsx
```

样例合计约 **19 行**（工行 7 + 建行 6 + 招行 6）。`samples` 里带 `scan` 的文件默认跳过；单独跑应提示无文本层。

---

## 转换你自己的流水

```bash
python extract_cn_bank.py 你的流水.pdf -o out/银行流水.xlsx
# 或整个文件夹：
python extract_cn_bank.py ./流水目录 -o out/银行流水.xlsx --csv out/银行流水.csv
```

建议先复制并打码账号、姓名再试。

---

## 首发支持版式

| 版式代码 | 银行 | 样例文件 |
|----------|------|----------|
| `icbc_like` | 工商银行风格明细 | `synth-icbc-statement.pdf` |
| `ccb_like` | 建设银行风格明细 | `synth-ccb-statement.pdf` |
| `cmb_like` | 招商银行风格流水 | `synth-cmb-statement.pdf` |

输出列：交易日期、交易时间、摘要、借方金额、贷方金额、余额、对方信息、版式、来源文件、备注。

真实网银模板（边框表、CID 字体、多行摘要）可能与合成样例不同 → 可能漏行/错列，请人工核对余额。反馈时请描述表头文字，**勿发未打码原件**。

---

## 失败回退（产品承诺）

| 情况 | 行为 |
|------|------|
| 扫描件 / 纯图 | 报错说明，不做 OCR |
| 无法识别银行 | 报错并提示支持列表 |
| 部分行解析失败 | 已识别行仍写出；说明 Sheet 记备注 |
| 支付宝 / 微信账单 PDF | **不支持**（请购账单类商品） |
| 电子发票 | **不支持**（请购发票包） |

---

## 能力边界

- **做**：工行/建行/招行文本层流水 → Excel/CSV；本地；样例可复现  
- **暂不做**：OCR；保证所有分行/所有月份模板；电子回单验真；风控/征信报告  
- **禁用**：伪造流水、套现包装相关咨询一律不做  

---

## 免责声明

辅助整理工具；结果须人工核对。隐私自负。数字商品售后以爱发电商品页为准。

## 同系列

电子发票→Excel 报销台账、英文/互金账单原型包（`bill-pdf-to-excel-cn`）。
