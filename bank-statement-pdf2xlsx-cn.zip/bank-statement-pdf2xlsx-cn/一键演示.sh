#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 -m venv .venv
# shellcheck disable=SC1091
source .venv/bin/activate
pip install -r requirements.txt
python extract_cn_bank.py samples -o out/银行流水.xlsx --csv out/银行流水.csv
echo "完成：out/银行流水.xlsx"
