#!/usr/bin/env python3
"""Regenerate CN bank statement synthetic PDFs (text-layer, one txn per line)."""
from __future__ import annotations

from pathlib import Path

from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.pdfgen import canvas

ROOT = Path(__file__).resolve().parents[1]
SAMPLES = ROOT / "samples"
FONT = "STSong-Light"
pdfmetrics.registerFont(UnicodeCIDFont(FONT))


def draw_lines(path: Path, title: str, meta: list[str], header: str, rows: list[str]) -> None:
    c = canvas.Canvas(str(path), pagesize=A4)
    w, h = A4
    y = h - 40
    c.setFont(FONT, 12)
    c.drawString(40, y, title)
    y -= 20
    c.setFont(FONT, 9)
    c.drawString(40, y, "SYNTHETIC / DESENSITIZED SAMPLE — NOT A REAL STATEMENT")
    y -= 16
    for m in meta:
        c.drawString(40, y, m)
        y -= 14
    y -= 6
    c.drawString(40, y, header)
    y -= 14
    for r in rows:
        if y < 40:
            c.showPage()
            c.setFont(FONT, 9)
            y = h - 40
        c.drawString(40, y, r)
        y -= 13
    c.save()
    print("wrote", path)


def main() -> None:
    SAMPLES.mkdir(parents=True, exist_ok=True)
    draw_lines(
        SAMPLES / "synth-icbc-statement.pdf",
        "中国工商银行（合成样例）借记卡账户历史明细清单",
        ["卡号：6212****6842  户名：测**  起止：2025-01-01~2025-01-31"],
        "交易日期 摘要 借方金额 贷方金额 余额 对方户名",
        [
            "2025-01-03 工资入账 - 12500.00 35600.21 某某科技有限公司",
            "2025-01-05 转账支出 2000.00 - 33600.21 李*",
            "2025-01-08 消费-超市 156.80 - 33443.41 某超市",
            "2025-01-12 利息结息 - 12.35 33455.76",
            "2025-01-18 网银转账 500.00 - 32955.76 王*",
            "2025-01-22 退款入账 - 89.00 33044.76 某电商",
            "2025-01-28 生活缴费 230.50 - 32814.26 供电公司",
        ],
    )
    draw_lines(
        SAMPLES / "synth-ccb-statement.pdf",
        "中国建设银行（合成样例）账户交易明细",
        ["账号：6227****1234  币种：人民币  打印日期：2025-02-01"],
        "记账日 交易地点/摘要 支出 收入 账户余额 对方账号",
        [
            "20250102 跨行汇入 - 8000.00 21000.00 6228****9999",
            "20250106 ATM取现 1000.00 - 20000.00",
            "20250110 POS消费 328.60 - 19671.40",
            "20250115 理财赎回 - 5000.00 24671.40",
            "20250120 代发工资 - 9800.00 34471.40 某单位",
            "20250125 水电费 186.20 - 34285.20",
        ],
    )
    draw_lines(
        SAMPLES / "synth-cmb-statement.pdf",
        "招商银行（合成样例）交易流水打印",
        ["账户：6214****5678  姓名：张**  查询区间：2025.01.01-2025.01.31"],
        "交易日期 交易时间 交易类型 交易金额 联机余额 交易备注",
        [
            "2025-01-04 09:12:33 转入 3000.00 15000.00 工资",
            "2025-01-07 18:40:01 消费 -88.50 14911.50 餐饮",
            "2025-01-11 11:05:22 转出 -1500.00 13411.50 还信用卡",
            "2025-01-16 14:20:00 转入 200.00 13611.50 好友转账",
            "2025-01-21 20:01:11 消费 -45.00 13566.50 出行",
            "2025-01-29 08:00:00 结息 3.21 13569.71 活期利息",
        ],
    )
    # image-only control via reportlab drawing (no text)
    from reportlab.lib.utils import ImageReader
    import io
    from PIL import Image, ImageDraw, ImageFont

    img = Image.new("RGB", (600, 200), "white")
    d = ImageDraw.Draw(img)
    d.text((20, 80), "SCAN IMAGE ONLY - NO TEXT LAYER", fill="black")
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    c = canvas.Canvas(str(SAMPLES / "synth-scan-no-textlayer.pdf"), pagesize=A4)
    c.drawImage(ImageReader(buf), 40, 500, width=500, height=160)
    c.save()
    print("wrote scan control")


if __name__ == "__main__":
    main()
