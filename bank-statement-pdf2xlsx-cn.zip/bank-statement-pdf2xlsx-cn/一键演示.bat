@echo off
cd /d %~dp0
python -m venv .venv
call .venv\Scripts\activate.bat
pip install -r requirements.txt
python extract_cn_bank.py samples -o out\银行流水.xlsx --csv out\银行流水.csv
echo Done: out\银行流水.xlsx
pause
