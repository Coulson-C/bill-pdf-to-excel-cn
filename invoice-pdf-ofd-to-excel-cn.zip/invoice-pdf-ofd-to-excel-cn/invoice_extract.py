#!/usr/bin/env python3
"""电子发票 PDF / XML / OFD(内嵌XML) → Excel 报销台账（本地、文本层/结构化）。

诚实边界：
- 优先 XML / OFD 内嵌 XML（字段稳）
- PDF：依赖可选中文字 + 关键词正则；扫描件/纯图 → 失败并说明
- 不查验真伪、不做 OCR、不联网
"""
from __future__ import annotations

import argparse
import csv
import re
import sys
import zipfile
import xml.etree.ElementTree as ET
from collections import Counter
from dataclasses import dataclass, field, asdict
from pathlib import Path

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, Alignment
from pypdf import PdfReader

HEADERS = [
    "来源文件",
    "票种",
    "发票代码",
    "发票号码",
    "开票日期",
    "销方名称",
    "销方税号",
    "购方名称",
    "购方税号",
    "金额",
    "税额",
    "价税合计",
    "解析方式",
    "状态",
    "备注",
    "查重标记",
]

ITEM_HEADERS = [
    "来源文件",
    "发票号码",
    "商品名称",
    "数量",
    "单价",
    "金额",
    "税率",
    "税额",
]


@dataclass
class InvoiceRow:
    来源文件: str = ""
    票种: str = ""
    发票代码: str = ""
    发票号码: str = ""
    开票日期: str = ""
    销方名称: str = ""
    销方税号: str = ""
    购方名称: str = ""
    购方税号: str = ""
    金额: str = ""
    税额: str = ""
    价税合计: str = ""
    解析方式: str = ""
    状态: str = "OK"
    备注: str = ""
    查重标记: str = ""
    items: list = field(default_factory=list, repr=False)


def pdf_text(path: Path) -> str:
    reader = PdfReader(str(path))
    return "\n".join((p.extract_text() or "") for p in reader.pages)


def _re_group(patterns: list[str], text: str) -> str:
    for pat in patterns:
        m = re.search(pat, text, re.M)
        if m:
            if m.lastindex:
                return m.group(1).strip()
            return m.group(0).strip()
    return ""


def parse_pdf(path: Path) -> InvoiceRow:
    text = pdf_text(path)
    row = InvoiceRow(来源文件=path.name, 解析方式="pdf_text")
    if not text.strip():
        row.状态 = "FAIL"
        row.备注 = "无文本层（可能是扫描件/纯图）。本包不做 OCR，请换税务平台电子原件 PDF/OFD/XML。"
        return row

    row.票种 = _re_group(
        [
            r"(数电票[^\n]{0,20}|电子发票[^\n]{0,20}|增值税专用发票|增值税普通发票)",
        ],
        text,
    )
    row.发票代码 = _re_group(
        [r"发票代码[:：\s]*([0-9]{10,12})"],
        text,
    )
    if "数电票无代码" in text and not re.search(r"发票代码[:：\s]*[0-9]", text):
        row.发票代码 = ""
    row.发票号码 = _re_group(
        [
            r"发票号码[:：\s]*([0-9]{8,20})",
            r"发票号码[:：\s]*([0-9A-Za-z]{8,20})",
        ],
        text,
    )
    row.开票日期 = _re_group(
        [
            r"开票日期[:：\s]*([0-9]{4}[-年/.][0-9]{1,2}[-月/.][0-9]{1,2}日?)",
        ],
        text,
    )
    row.销方名称 = _re_group([r"销售方名称[:：\s]*([^\n]+)"], text)
    row.销方税号 = _re_group(
        [r"销售方纳税人识别号[:：\s]*([0-9A-Z]{15,20})", r"销方税号[:：\s]*([0-9A-Z]{15,20})"],
        text,
    )
    row.购方名称 = _re_group([r"购买方名称[:：\s]*([^\n]+)"], text)
    row.购方税号 = _re_group(
        [r"购买方纳税人识别号[:：\s]*([0-9A-Z]{15,20})", r"购方税号[:：\s]*([0-9A-Z]{15,20})"],
        text,
    )
    row.金额 = _re_group([r"(?<![价税合])金额[:：\s]*¥?([0-9,]+\.\d{2})"], text)
    row.税额 = _re_group([r"(?<!价税合)税额[:：\s]*¥?([0-9,]+\.\d{2})"], text)
    row.价税合计 = _re_group(
        [r"价税合计[:：\s]*¥?([0-9,]+\.\d{2})", r"价税合计[:：\s]*[（(]?小写[）)]?[:：\s]*¥?([0-9,]+\.\d{2})"],
        text,
    )

    # line items heuristic
    for m in re.finditer(
        r"(\*[^*\n]+\*\S*)\s+([0-9.]+)\s+([0-9.]+)\s+([0-9.]+)\s+([0-9.]+%)\s+([0-9.]+)",
        text,
    ):
        row.items.append(
            {
                "商品名称": m.group(1).strip(),
                "数量": m.group(2),
                "单价": m.group(3),
                "金额": m.group(4),
                "税率": m.group(5),
                "税额": m.group(6),
            }
        )

    if not row.发票号码 and not row.价税合计:
        row.状态 = "FAIL"
        row.备注 = "未能识别关键字段（版式可能非标准）。请优先使用同票的 XML/OFD，或反馈表头关键词（勿发未打码原件）。"
    elif not row.发票号码:
        row.状态 = "PARTIAL"
        row.备注 = "缺发票号码，请人工核对。"
    return row


def _xml_local(tag: str) -> str:
    return tag.split("}")[-1] if "}" in tag else tag


def _find_text(root: ET.Element, names: list[str]) -> str:
    want = {n.lower() for n in names}
    for el in root.iter():
        if _xml_local(el.tag).lower() in want and (el.text or "").strip():
            return (el.text or "").strip()
    return ""


def parse_xml_bytes(data: bytes, source_name: str, via: str) -> InvoiceRow:
    row = InvoiceRow(来源文件=source_name, 解析方式=via)
    try:
        root = ET.fromstring(data)
    except ET.ParseError as e:
        row.状态 = "FAIL"
        row.备注 = f"XML 解析失败: {e}"
        return row

    row.票种 = _find_text(root, ["InvoiceType", "票种", "Type"])
    row.发票代码 = _find_text(root, ["InvoiceCode", "发票代码"])
    row.发票号码 = _find_text(root, ["InvoiceNumber", "发票号码", "Number"])
    row.开票日期 = _find_text(root, ["IssueDate", "开票日期", "Date"])
    # Seller / Buyer may be nested
    for el in root.iter():
        loc = _xml_local(el.tag).lower()
        if loc == "seller":
            row.销方名称 = row.销方名称 or _find_text(el, ["Name", "名称"])
            row.销方税号 = row.销方税号 or _find_text(el, ["TaxId", "税号", "TaxpayerId"])
        if loc == "buyer":
            row.购方名称 = row.购方名称 or _find_text(el, ["Name", "名称"])
            row.购方税号 = row.购方税号 or _find_text(el, ["TaxId", "税号", "TaxpayerId"])
    row.销方名称 = row.销方名称 or _find_text(root, ["SellerName", "销方名称"])
    row.销方税号 = row.销方税号 or _find_text(root, ["SellerTaxId", "销方税号"])
    row.购方名称 = row.购方名称 or _find_text(root, ["BuyerName", "购方名称"])
    row.购方税号 = row.购方税号 or _find_text(root, ["BuyerTaxId", "购方税号"])
    row.金额 = _find_text(root, ["AmountExcludingTax", "金额", "TotalAmountWithoutTax"])
    row.税额 = _find_text(root, ["TaxAmount", "税额", "TotalTaxAmount"])
    row.价税合计 = _find_text(root, ["TotalAmount", "价税合计", "AmountWithTax"])

    for el in root.iter():
        if _xml_local(el.tag).lower() not in {"item", "goodslist", "detail"}:
            # also match Goods* children sometimes named Item
            pass
        if _xml_local(el.tag).lower() == "item":
            row.items.append(
                {
                    "商品名称": _find_text(el, ["Name", "商品名称", "ItemName"]),
                    "数量": _find_text(el, ["Quantity", "数量"]),
                    "单价": _find_text(el, ["Price", "单价"]),
                    "金额": _find_text(el, ["Amount", "金额"]),
                    "税率": _find_text(el, ["TaxRate", "税率"]),
                    "税额": _find_text(el, ["Tax", "税额"]),
                }
            )

    if not row.发票号码:
        row.状态 = "FAIL"
        row.备注 = "XML 中未找到发票号码字段。"
    return row


def parse_xml_file(path: Path) -> InvoiceRow:
    return parse_xml_bytes(path.read_bytes(), path.name, "xml")


def parse_ofd(path: Path) -> InvoiceRow:
    """OFD ≈ zip；搜索内嵌含 InvoiceNumber / 发票号码 的 XML。"""
    try:
        with zipfile.ZipFile(path, "r") as zf:
            xml_names = [n for n in zf.namelist() if n.lower().endswith(".xml")]
            # Prefer attach / invoice named
            xml_names.sort(
                key=lambda n: (
                    0
                    if any(k in n.lower() for k in ("invoice", "attach", "original", "发票"))
                    else 1,
                    len(n),
                )
            )
            for name in xml_names:
                data = zf.read(name)
                if b"InvoiceNumber" in data or "发票号码".encode("utf-8") in data or b"EInvoice" in data:
                    row = parse_xml_bytes(data, path.name, f"ofd_xml:{name}")
                    return row
            row = InvoiceRow(来源文件=path.name, 解析方式="ofd", 状态="FAIL")
            row.备注 = "OFD 内未找到含发票号码的 XML。部分税局 OFD 结构不同；请同时保留同票 XML 或用 PDF。"
            return row
    except zipfile.BadZipFile:
        row = InvoiceRow(来源文件=path.name, 解析方式="ofd", 状态="FAIL")
        row.备注 = "文件不是有效 OFD/ZIP。"
        return row


def parse_one(path: Path) -> InvoiceRow:
    suf = path.suffix.lower()
    if suf == ".xml":
        return parse_xml_file(path)
    if suf == ".ofd":
        return parse_ofd(path)
    if suf == ".pdf":
        return parse_pdf(path)
    row = InvoiceRow(来源文件=path.name, 状态="FAIL", 备注=f"不支持的扩展名: {suf}")
    return row


def collect_inputs(paths: list[Path]) -> list[Path]:
    files: list[Path] = []
    for p in paths:
        if p.is_dir():
            for ext in ("*.pdf", "*.xml", "*.ofd", "*.PDF", "*.XML", "*.OFD"):
                files.extend(sorted(p.glob(ext)))
        elif p.is_file():
            files.append(p)
    # Prefer XML over same-stem PDF/OFD to avoid triple rows for demos
    by_stem: dict[str, list[Path]] = {}
    for f in files:
        by_stem.setdefault(f.stem.lower(), []).append(f)
    chosen: list[Path] = []
    for stem, group in by_stem.items():
        xmls = [g for g in group if g.suffix.lower() == ".xml"]
        if xmls:
            chosen.append(xmls[0])
            continue
        ofds = [g for g in group if g.suffix.lower() == ".ofd"]
        if ofds:
            chosen.append(ofds[0])
            continue
        chosen.extend(group)
    return sorted(chosen, key=lambda x: x.name)


def mark_duplicates(rows: list[InvoiceRow]) -> None:
    nums = [r.发票号码 for r in rows if r.发票号码]
    cnt = Counter(nums)
    for r in rows:
        if r.发票号码 and cnt[r.发票号码] > 1:
            r.查重标记 = "重复发票号码"


def write_xlsx(rows: list[InvoiceRow], out: Path) -> None:
    wb = Workbook()
    ws = wb.active
    ws.title = "报销台账"
    ws.append(HEADERS)
    for cell in ws[1]:
        cell.font = Font(bold=True)
    for r in rows:
        d = asdict(r)
        d.pop("items", None)
        # Force invoice number as text
        values = []
        for h in HEADERS:
            v = d.get(h, "")
            if h in ("发票号码", "发票代码", "销方税号", "购方税号") and v is not None:
                v = str(v)
            values.append(v)
        ws.append(values)
        # set number columns as text for 发票号码
        row_idx = ws.max_row
        for col_name in ("发票号码", "发票代码", "销方税号", "购方税号"):
            col = HEADERS.index(col_name) + 1
            cell = ws.cell(row=row_idx, column=col)
            cell.number_format = "@"
            cell.alignment = Alignment(horizontal="left")
            if cell.value is not None:
                cell.value = str(cell.value)

    # totals row for OK amounts
    def to_f(s: str) -> float:
        try:
            return float(str(s).replace(",", ""))
        except Exception:
            return 0.0

    ok = [r for r in rows if r.状态 in ("OK", "PARTIAL") and r.价税合计]
    if ok:
        ws.append([])
        ws.append(
            [
                "合计(成功/部分)",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                f"{sum(to_f(r.金额) for r in ok):.2f}",
                f"{sum(to_f(r.税额) for r in ok):.2f}",
                f"{sum(to_f(r.价税合计) for r in ok):.2f}",
                "",
                "",
                f"{len(ok)} 张",
                "",
            ]
        )

    ws2 = wb.create_sheet("商品明细")
    ws2.append(ITEM_HEADERS)
    for cell in ws2[1]:
        cell.font = Font(bold=True)
    for r in rows:
        for it in r.items:
            ws2.append(
                [
                    r.来源文件,
                    str(r.发票号码),
                    it.get("商品名称", ""),
                    it.get("数量", ""),
                    it.get("单价", ""),
                    it.get("金额", ""),
                    it.get("税率", ""),
                    it.get("税额", ""),
                ]
            )

    ws3 = wb.create_sheet("失败说明")
    ws3.append(["来源文件", "状态", "备注"])
    for r in rows:
        if r.状态 != "OK":
            ws3.append([r.来源文件, r.状态, r.备注])
    if ws3.max_row == 1:
        ws3.append(["（无）", "", "本批全部成功或无失败行"])

    out.parent.mkdir(parents=True, exist_ok=True)
    wb.save(out)


def write_blank_template(path: Path) -> None:
    wb = Workbook()
    ws = wb.active
    ws.title = "报销台账"
    ws.append(HEADERS)
    for cell in ws[1]:
        cell.font = Font(bold=True)
    wb.create_sheet("商品明细").append(ITEM_HEADERS)
    path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(path)


def write_csv(rows: list[InvoiceRow], out: Path) -> None:
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=HEADERS, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            d = asdict(r)
            d.pop("items", None)
            w.writerow(d)


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="电子发票 → Excel 报销台账（本地）")
    ap.add_argument("inputs", nargs="+", help="文件或文件夹（pdf/xml/ofd）")
    ap.add_argument("-o", "--output", default="out/报销台账.xlsx", help="输出 xlsx 路径")
    ap.add_argument("--csv", dest="csv_out", default="", help="额外输出 CSV")
    ap.add_argument("--all-formats", action="store_true", help="同名 xml/pdf/ofd 都解析（默认同名优先 XML）")
    args = ap.parse_args(argv)

    paths = [Path(p) for p in args.inputs]
    if args.all_formats:
        files: list[Path] = []
        for p in paths:
            if p.is_dir():
                for ext in ("*.pdf", "*.xml", "*.ofd"):
                    files.extend(sorted(p.glob(ext)))
            else:
                files.append(p)
    else:
        files = collect_inputs(paths)

    if not files:
        print("未找到可处理文件（pdf/xml/ofd）。", file=sys.stderr)
        return 2

    rows = [parse_one(f) for f in files]
    mark_duplicates(rows)
    out = Path(args.output)
    write_xlsx(rows, out)
    if args.csv_out:
        write_csv(rows, Path(args.csv_out))

    ok = sum(1 for r in rows if r.状态 == "OK")
    partial = sum(1 for r in rows if r.状态 == "PARTIAL")
    fail = sum(1 for r in rows if r.状态 == "FAIL")
    print(f"完成: {len(rows)} 张 → {out}  (OK={ok} PARTIAL={partial} FAIL={fail})")
    for r in rows:
        if r.状态 != "OK":
            print(f"  [{r.状态}] {r.来源文件}: {r.备注}")
    return 0 if fail == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
