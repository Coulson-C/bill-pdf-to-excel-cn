#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 -m venv .venv
# shellcheck disable=SC1091
source .venv/bin/activate
pip install -r requirements.txt
python invoice_extract.py samples -o out/报销台账.xlsx --csv out/报销台账.csv
echo "完成：out/报销台账.xlsx"
