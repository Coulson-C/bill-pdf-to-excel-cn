@echo off
cd /d %~dp0
python -m venv .venv
call .venv\Scripts\activate.bat
pip install -r requirements.txt
python invoice_extract.py samples -o out\报销台账.xlsx --csv out\报销台账.csv
echo Done: out\报销台账.xlsx
pause
