#!/usr/bin/env python3
"""Generate fictional Chinese e-invoice samples (PDF + XML + OFD-like zip). No real PII."""
from __future__ import annotations

import json
import zipfile
from pathlib import Path

from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.pdfgen import canvas

pdfmetrics.registerFont(UnicodeCIDFont("STSong-Light"))

ROOT = Path(__file__).resolve().parents[1]
SAMPLES = ROOT / "samples"
EXPECTED = ROOT / "expected"

# Prefer a CJK-capable font if present on the box

INVOICES = [
    {
        "kind": "数电票(增值税专用发票)",
        "code": "",  # 数电票常无代码
        "number": "24312000000012345678",
        "date": "2025-01-15",
        "seller_name": "演示科技有限公司",
        "seller_tax": "91310000MA1DEMO001",
        "buyer_name": "测试贸易有限公司",
        "buyer_tax": "91310000MA1BUYER02",
        "amount": "884.96",
        "tax": "115.04",
        "total": "1000.00",
        "items": [
            {"name": "*信息技术服务*软件服务费", "qty": "1", "price": "884.96", "amount": "884.96", "tax_rate": "13%", "tax": "115.04"},
        ],
    },
    {
        "kind": "电子发票(普通发票)",
        "code": "044001900111",
        "number": "98765432",
        "date": "2025-02-03",
        "seller_name": "演示餐饮管理有限公司",
        "seller_tax": "91310000MA1FOOD003",
        "buyer_name": "测试贸易有限公司",
        "buyer_tax": "91310000MA1BUYER02",
        "amount": "176.99",
        "tax": "23.01",
        "total": "200.00",
        "items": [
            {"name": "*餐饮服务*餐费", "qty": "1", "price": "176.99", "amount": "176.99", "tax_rate": "13%", "tax": "23.01"},
        ],
    },
]


def write_pdf(inv: dict, path: Path, font_name: str) -> None:
    c = canvas.Canvas(str(path), pagesize=A4)
    w, h = A4
    y = h - 50
    c.setFont(font_name, 14)
    c.drawString(50, y, f"电子发票（合成样例）— {inv['kind']}")
    y -= 28
    c.setFont(font_name, 10)
    lines = [
        "SYNTHETIC / DESENSITIZED — NOT A REAL INVOICE",
        f"发票代码: {inv['code'] or '（数电票无代码）'}",
        f"发票号码: {inv['number']}",
        f"开票日期: {inv['date']}",
        f"销售方名称: {inv['seller_name']}",
        f"销售方纳税人识别号: {inv['seller_tax']}",
        f"购买方名称: {inv['buyer_name']}",
        f"购买方纳税人识别号: {inv['buyer_tax']}",
        f"金额: {inv['amount']}",
        f"税额: {inv['tax']}",
        f"价税合计: ¥{inv['total']}",
        "",
        "货物或应税劳务、服务名称  数量  单价  金额  税率  税额",
    ]
    for line in lines:
        c.drawString(50, y, line)
        y -= 16
    for it in inv["items"]:
        row = f"{it['name']}  {it['qty']}  {it['price']}  {it['amount']}  {it['tax_rate']}  {it['tax']}"
        c.drawString(50, y, row)
        y -= 16
    c.save()


def write_xml(inv: dict, path: Path) -> None:
    # Minimal e-invoice-like XML (fictional schema labels in Chinese comments)
    items_xml = []
    for it in inv["items"]:
        items_xml.append(
            f"""    <Item>
      <Name>{it['name']}</Name>
      <Quantity>{it['qty']}</Quantity>
      <Price>{it['price']}</Price>
      <Amount>{it['amount']}</Amount>
      <TaxRate>{it['tax_rate']}</TaxRate>
      <Tax>{it['tax']}</Tax>
    </Item>"""
        )
    xml = f"""<?xml version="1.0" encoding="UTF-8"?>
<!-- SYNTHETIC DEMO e-invoice XML — not a real tax authority file -->
<EInvoice>
  <Header>
    <InvoiceType>{inv['kind']}</InvoiceType>
    <InvoiceCode>{inv['code']}</InvoiceCode>
    <InvoiceNumber>{inv['number']}</InvoiceNumber>
    <IssueDate>{inv['date']}</IssueDate>
  </Header>
  <Seller>
    <Name>{inv['seller_name']}</Name>
    <TaxId>{inv['seller_tax']}</TaxId>
  </Seller>
  <Buyer>
    <Name>{inv['buyer_name']}</Name>
    <TaxId>{inv['buyer_tax']}</TaxId>
  </Buyer>
  <Amounts>
    <AmountExcludingTax>{inv['amount']}</AmountExcludingTax>
    <TaxAmount>{inv['tax']}</TaxAmount>
    <TotalAmount>{inv['total']}</TotalAmount>
  </Amounts>
  <Items>
{chr(10).join(items_xml)}
  </Items>
</EInvoice>
"""
    path.write_text(xml, encoding="utf-8")


def write_ofd_like(inv: dict, path: Path) -> None:
    """OFD is a zip; put a recognizable invoice XML inside for our reader."""
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        zf.writestr(
            "OFD.xml",
            '<?xml version="1.0"?><OFD DocType="OFD" Version="1.0"><DocBody/></OFD>\n',
        )
        # Nested path common in real OFD; our extractor searches for InvoiceNumber tags
        inner = path.with_suffix(".inner.xml")
        write_xml(inv, inner)
        zf.writestr("Doc_0/Attachs/original_invoice.xml", inner.read_text(encoding="utf-8"))
        inner.unlink(missing_ok=True)


def main() -> None:
    SAMPLES.mkdir(parents=True, exist_ok=True)
    EXPECTED.mkdir(parents=True, exist_ok=True)
    font_name = "STSong-Light"

    expected_rows = []
    for i, inv in enumerate(INVOICES, 1):
        stem = f"demo_invoice_{i:02d}"
        pdf_path = SAMPLES / f"{stem}.pdf"
        xml_path = SAMPLES / f"{stem}.xml"
        ofd_path = SAMPLES / f"{stem}.ofd"
        write_pdf(inv, pdf_path, font_name)
        write_xml(inv, xml_path)
        write_ofd_like(inv, ofd_path)
        expected_rows.append(
            {
                "source": f"{stem}.xml",
                "发票代码": inv["code"],
                "发票号码": inv["number"],
                "开票日期": inv["date"],
                "销方名称": inv["seller_name"],
                "销方税号": inv["seller_tax"],
                "购方名称": inv["buyer_name"],
                "购方税号": inv["buyer_tax"],
                "金额": inv["amount"],
                "税额": inv["tax"],
                "价税合计": inv["total"],
                "票种": inv["kind"],
            }
        )
        print("wrote", pdf_path.name, xml_path.name, ofd_path.name)

    (EXPECTED / "expected_ledger.json").write_text(
        json.dumps(expected_rows, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print("expected →", EXPECTED / "expected_ledger.json")


if __name__ == "__main__":
    main()
