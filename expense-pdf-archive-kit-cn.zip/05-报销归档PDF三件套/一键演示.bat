@echo off
chcp 65001 >nul
cd /d "%~dp0"
python -m venv .venv
call .venv\Scripts\activate.bat
pip install -r requirements.txt
python scripts\generate_samples.py
python pdf_archive.py rename samples -o out --manifest manifests\归档清单示例.csv --template "{日期}_{金额}_{发票号}.pdf" --watermark "仅供报销归档" --wm-style both --merge --merge-name "2026-10_报销归档包_仅供报销归档_3张.pdf"
echo Done. See out\
pause
