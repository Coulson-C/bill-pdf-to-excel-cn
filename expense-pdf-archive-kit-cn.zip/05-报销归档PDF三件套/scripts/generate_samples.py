#!/usr/bin/env python3
"""生成脱敏占位 PDF + 清单 CSV（非真实发票版式）。"""
from pathlib import Path
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4

ROOT = Path(__file__).resolve().parents[1]
samples = ROOT / "samples"
manifests = ROOT / "manifests"
samples.mkdir(parents=True, exist_ok=True)
manifests.mkdir(parents=True, exist_ok=True)

def one(name: str, lines: list) -> None:
    path = samples / name
    c = canvas.Canvas(str(path), pagesize=A4)
    c.setFont("Helvetica", 14)
    y = 800
    c.drawString(72, y, "DEMO PLACEHOLDER - NOT A REAL INVOICE")
    y -= 28
    for line in lines:
        c.drawString(72, y, line)
        y -= 22
    c.showPage()
    c.save()

one("微信图片_20261015_142233.pdf", ["Messy phone export name", "Amount hint: 1280.00"])
one("dzfp_messy_vendor.pdf", ["Vendor export name", "Amount hint: 356.50"])
one("发票(1).pdf", ["Generic download name", "Amount hint: 89.00"])

csv_path = manifests / "归档清单示例.csv"
csv_path.write_text(
    "\ufeff文件,日期,金额,发票号,备注\n"
    "微信图片_20261015_142233.pdf,2026-10-12,1280.00,25322000000123456789,差旅\n"
    "dzfp_messy_vendor.pdf,2026-10-14,356.50,25322000000987654321,办公\n"
    "发票(1).pdf,2026-10-15,89.00,25322000000555555555,快递\n",
    encoding="utf-8",
)
print("samples + manifest ready")
