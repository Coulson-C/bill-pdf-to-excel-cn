# 报销归档 PDF 三件套（合并 · 水印 · 规则改名）

把本月一堆电子票 PDF：**按清单改名 → 打归档水印 → 合并成一份归档包**。  
**本地处理。不做发票字段抽取、不做验真/税控。**  
（字段抽取请用同系列「发票 PDF/OFD→Excel」包，二者边界分开。）

版本：burn-night-2026-10-31 · 建议标价 **¥39** 买断

---

## 包内有什么

| 内容 | 说明 |
|------|------|
| `pdf_archive.py` | 主程序：`rename` / `merge` 子命令 |
| `requirements.txt` | pypdf + reportlab |
| `manifests/归档清单示例.csv` | 字段清单模板（演示） |
| `scripts/generate_samples.py` | 生成占位 PDF（非真票） |
| `一键演示.sh` / `.bat` | 一键跑通 |
| `01_免责声明.txt` | 必读 |

---

## 环境

- Windows 10/11、macOS 或 Linux
- Python **3.10+**
- 本地 CPU

---

## 安装与演示

```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python scripts/generate_samples.py
python pdf_archive.py rename samples -o out \
  --manifest manifests/归档清单示例.csv \
  --template "{日期}_{金额}_{发票号}.pdf" \
  --watermark "仅供报销归档" --wm-style both --merge \
  --merge-name "2026-10_报销归档包_仅供报销归档_3张.pdf"
```

查看 `out/renamed/` 与合并包；**`samples/` 原件不改动**。

---

## 处理你自己的票面文件

1. 准备文件夹：只放 **PDF**（OFD 请先自行转为 PDF；本 V1 不保证 OFD 原生合并）。  
2. 复制 `manifests/归档清单示例.csv`，按「文件,日期,金额,发票号,备注」填好（文件名须与文件夹内一致）。  
3. 运行：

```bash
python pdf_archive.py rename 你的文件夹 -o out --manifest 你的清单.csv \
  --template "{日期}_{金额}_{发票号}.pdf" \
  --watermark "仅供报销归档-某某公司" --merge
```

仅合并：

```bash
python pdf_archive.py merge 你的文件夹 -o out --watermark "仅供报销归档" --merge-name 本月归档.pdf
```

水印样式：`--wm-style header|diagonal|both`（`both`=页眉+斜向「骑缝风格」，**不是**印章级骑缝章）。

---

## 与「发票→Excel」划界

| | 本包（归档） | 发票→Excel 包 |
|--|-------------|---------------|
| 目标 | 文件名规范 + 水印 + 合并 | 票面字段进台账表 |
| 字段来源 | **您填的 CSV 清单** | 解析 PDF/OFD/XML |
| 验真/税控 | 否 | 否 |

---

## 能力边界

**能做：** PDF 批量重命名、文字水印、多文件合并、失败/未匹配警告清单。  
**不做：** OCR 抽字段、OFD 全版本保证、加密票破解、改 PDF 正文、查验真伪、抵扣勾选、银行流水/差旅 Excel。

---

## 免责

详见 `01_免责声明.txt`。
