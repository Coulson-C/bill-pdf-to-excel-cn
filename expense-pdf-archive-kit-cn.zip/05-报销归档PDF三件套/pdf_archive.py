#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""报销归档 PDF：规则重命名 + 可选水印 + 合并。不做发票字段抽取/验真。"""
from __future__ import annotations

import argparse
import csv
import re
import sys
from io import BytesIO
from pathlib import Path

from pypdf import PdfReader, PdfWriter
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas

SAFE_CHARS = re.compile(r'[\\/:*?"<>|\s]+')


def register_font() -> str:
    for c in (
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "C:/Windows/Fonts/msyh.ttc",
        "C:/Windows/Fonts/simhei.ttf",
        "/System/Library/Fonts/PingFang.ttc",
    ):
        if Path(c).is_file():
            try:
                pdfmetrics.registerFont(TTFont("ArchiveFont", c))
                return "ArchiveFont"
            except Exception:
                continue
    return "Helvetica"


def sanitize(s: str, max_len: int = 100) -> str:
    s = SAFE_CHARS.sub("_", str(s).strip())
    s = s.strip("._") or "unnamed"
    return s[:max_len]


def load_manifest(path: Path) -> dict[str, dict[str, str]]:
    """返回 {原文件名: 字段dict}。支持中英表头。"""
    mapping = {
        "文件": "file",
        "原文件": "file",
        "file": "file",
        "filename": "file",
        "日期": "date",
        "date": "date",
        "金额": "amount",
        "amount": "amount",
        "发票号": "invoice_no",
        "发票号码": "invoice_no",
        "invoice_no": "invoice_no",
        "备注": "extra",
        "extra": "extra",
    }
    by_file: dict[str, dict[str, str]] = {}
    with path.open(encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        for raw in reader:
            norm: dict[str, str] = {}
            for k, v in raw.items():
                if k is None:
                    continue
                key = mapping.get(k.strip()) or mapping.get(k.strip().lower())
                if key:
                    norm[key] = (v or "").strip()
            fname = norm.get("file")
            if fname:
                by_file[Path(fname).name] = norm
    return by_file


def apply_template(tpl: str, fields: dict[str, str], fallback_stem: str) -> str:
    data = {
        "日期": fields.get("date", ""),
        "金额": fields.get("amount", ""),
        "发票号": fields.get("invoice_no", ""),
        "备注": fields.get("extra", ""),
        "date": fields.get("date", ""),
        "amount": fields.get("amount", ""),
        "invoice_no": fields.get("invoice_no", ""),
        "extra": fields.get("extra", ""),
        "原名": fallback_stem,
        "stem": fallback_stem,
    }
    out = tpl
    for k, v in data.items():
        out = out.replace("{" + k + "}", v)
    out = sanitize(out)
    if not out.lower().endswith(".pdf"):
        out += ".pdf"
    return out


def make_watermark_page(width: float, height: float, text: str, font_name: str, style: str):
    buf = BytesIO()
    c = canvas.Canvas(buf, pagesize=(width, height))
    c.setFillGray(0.5)
    c.setFillAlpha(0.28)
    size = max(12, int(min(width, height) / 22))
    c.setFont(font_name, size)
    if style in ("header", "both"):
        c.drawString(36, height - 40, text)
    if style in ("diagonal", "both"):
        c.saveState()
        c.translate(width / 2, height / 2)
        c.rotate(32)
        c.setFont(font_name, max(14, int(min(width, height) / 16)))
        c.drawCentredString(0, 0, text)
        c.restoreState()
    c.save()
    buf.seek(0)
    return PdfReader(buf).pages[0]


def open_reader(src: Path) -> PdfReader:
    reader = PdfReader(str(src))
    if reader.is_encrypted:
        try:
            reader.decrypt("")
        except Exception as e:  # noqa: BLE001
            raise RuntimeError(f"加密 PDF 无法打开: {src.name}") from e
    return reader


def write_pdf(src: Path, dest: Path, watermark: str, style: str, font_name: str) -> None:
    reader = open_reader(src)
    writer = PdfWriter()
    for page in reader.pages:
        if watermark:
            box = page.mediabox
            wm = make_watermark_page(float(box.width), float(box.height), watermark, font_name, style)
            page.merge_page(wm)
        writer.add_page(page)
    dest.parent.mkdir(parents=True, exist_ok=True)
    with dest.open("wb") as f:
        writer.write(f)


def merge_pdfs(paths: list[Path], dest: Path, watermark: str, style: str, font_name: str) -> None:
    writer = PdfWriter()
    for p in paths:
        reader = open_reader(p)
        for page in reader.pages:
            if watermark:
                box = page.mediabox
                wm = make_watermark_page(
                    float(box.width), float(box.height), watermark, font_name, style
                )
                page.merge_page(wm)
            writer.add_page(page)
    dest.parent.mkdir(parents=True, exist_ok=True)
    with dest.open("wb") as f:
        writer.write(f)


def cmd_rename(args: argparse.Namespace, font_name: str) -> int:
    folder: Path = args.input_dir
    out: Path = args.out
    out.mkdir(parents=True, exist_ok=True)
    by_file = load_manifest(args.manifest) if args.manifest else {}

    pdfs = sorted(
        [p for p in folder.iterdir() if p.suffix.lower() == ".pdf"],
        key=lambda x: x.name.lower(),
    )
    if not pdfs:
        print("目录内无 PDF", file=sys.stderr)
        return 1

    # 无清单时：用原名作为默认模板更安全
    template = args.template
    if not args.manifest and template == "{日期}_{金额}_{发票号}.pdf":
        template = "{原名}.pdf"
        print("提示：未提供 --manifest，已改用模板 {原名}.pdf（避免空字段文件名）")

    renamed: list[Path] = []
    logs: list[str] = []
    for i, src in enumerate(pdfs, 1):
        fields = by_file.get(src.name)
        if args.manifest and fields is None:
            fields = {
                "date": "未知日期",
                "amount": "0",
                "invoice_no": f"{i:03d}",
                "extra": "",
            }
            logs.append(f"WARN 清单无匹配，用占位字段: {src.name}")
        if fields is None:
            fields = {}
        name = apply_template(template, fields, src.stem)
        dest = out / "renamed" / name
        n = 1
        while dest.exists():
            dest = out / "renamed" / f"{Path(name).stem}_{n}.pdf"
            n += 1
        try:
            write_pdf(src, dest, args.watermark, args.wm_style, font_name)
            renamed.append(dest)
            print(f"[OK] {src.name} → {dest.relative_to(out)}")
        except Exception as e:  # noqa: BLE001
            logs.append(f"FAIL {src.name}: {e}")
            print(f"[FAIL] {src.name}: {e}", file=sys.stderr)

    if args.merge and renamed:
        merge_dest = out / sanitize(args.merge_name)
        try:
            # 单票若已盖水印，合并时不再叠加
            merge_pdfs(renamed, merge_dest, "", args.wm_style, font_name)
            print(f"[MERGE] {len(renamed)} 份 → {merge_dest.name}")
        except Exception as e:  # noqa: BLE001
            logs.append(f"MERGE FAIL: {e}")
            print(f"[MERGE FAIL] {e}", file=sys.stderr)

    if logs:
        log_path = out / "失败与警告清单.txt"
        log_path.write_text("\n".join(logs) + "\n", encoding="utf-8")
        print(f"日志: {log_path}")

    print(f"完成：成功 {len(renamed)}/{len(pdfs)}；源文件未修改。")
    print("边界：本工具只做归档整理，不做发票 OCR/字段抽取/验真。")
    return 0 if renamed else 1


def cmd_merge(args: argparse.Namespace, font_name: str) -> int:
    folder: Path = args.input_dir
    pdfs = sorted([p for p in folder.iterdir() if p.suffix.lower() == ".pdf"], key=lambda x: x.name.lower())
    if not pdfs:
        print("目录内无 PDF", file=sys.stderr)
        return 1
    args.out.mkdir(parents=True, exist_ok=True)
    dest = args.out / sanitize(args.merge_name)
    merge_pdfs(pdfs, dest, args.watermark, args.wm_style, font_name)
    print(f"[MERGE] {len(pdfs)} → {dest}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(description="报销归档：重命名 + 水印 + 合并（本地）")
    sub = ap.add_subparsers(dest="cmd", required=True)

    r = sub.add_parser("rename", help="按清单/模板重命名，可选水印与合并")
    r.add_argument("input_dir", type=Path)
    r.add_argument("-o", "--out", type=Path, default=Path("out"))
    r.add_argument("--manifest", type=Path, help="CSV 清单")
    r.add_argument("--template", default="{日期}_{金额}_{发票号}.pdf")
    r.add_argument("--watermark", default="")
    r.add_argument("--wm-style", choices=["header", "diagonal", "both"], default="both")
    r.add_argument("--merge", action="store_true")
    r.add_argument("--merge-name", default="报销归档包_仅供报销归档.pdf")

    m = sub.add_parser("merge", help="仅合并（可选水印）")
    m.add_argument("input_dir", type=Path)
    m.add_argument("-o", "--out", type=Path, default=Path("out"))
    m.add_argument("--watermark", default="")
    m.add_argument("--wm-style", choices=["header", "diagonal", "both"], default="both")
    m.add_argument("--merge-name", default="合并归档.pdf")
    return ap


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    font = register_font()
    if args.cmd == "rename":
        return cmd_rename(args, font)
    if args.cmd == "merge":
        return cmd_merge(args, font)
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
