# 电商主图本地批处理（压图 · 多尺寸 · 水印）

一张源图 → 淘宝 / 拼多多 / 京东 / 抖店常见尺寸文件夹；可选压到目标 KB、打文字水印。  
**图在本机处理，不上传。不做 AI 超分、不承诺商用抠图。**

版本：burn-night-2026-10-31 · 建议标价 **¥49** 买断

---

## 包内有什么

| 内容 | 说明 |
|------|------|
| `image_batch.py` | 主程序 |
| `presets/ecommerce_cn.json` | 中文电商尺寸预设 |
| `requirements.txt` | 仅需 Pillow |
| `一键演示.sh` / `.bat` | 生成样例并跑通 |
| `scripts/generate_samples.py` | 色块演示图（非实拍商品） |
| `01_免责声明.txt` | 请先阅读 |

---

## 环境

- Windows 10/11、macOS 或 Linux
- Python **3.10+**
- 本地 CPU；无需独立显卡

---

## 安装与演示

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
python scripts/generate_samples.py
python image_batch.py samples -o out --presets presets/ecommerce_cn.json --quality 80 --max-kb 300 --watermark "仅供店铺演示" --keep-name
```

或运行 `一键演示.bat` / `bash 一键演示.sh`。  
打开 `out/taobao_800/` 等子文件夹；**`samples/` 原图不会被改写**。

---

## 处理你自己的主图

1. 把 JPG/PNG/WebP 放进一个文件夹。  
2. 运行：

```bash
python image_batch.py 你的图片文件夹 -o out --presets presets/ecommerce_cn.json --quality 82 --max-kb 500 --watermark "你的店名" --keep-name
```

常用参数：

| 参数 | 含义 |
|------|------|
| `--only taobao_800 detail_750` | 只导出部分预设 |
| `--format webp` | 输出 WebP |
| `--max-kb 300` | 逼近单张体积上限（JPEG/WebP） |
| `--wm-pos center` | 水印位置 |
| `--recursive` | 含子目录 |

自定义预设：复制 `presets/ecommerce_cn.json` 改边长后 `--presets 你的.json`。

---

## 能力边界

**能做：** 批量缩放/方图裁切、质量或目标 KB 压缩、多文件夹导出、文字水印、保留原图。  
**不做：** GPU/AI 超分、自动抠图、批量修图美颜、云端同步、替你过平台审核。  
平台对主图规则可能变更；导出后请人工目检再上传。

---

## 免责（摘要）

见 `01_免责声明.txt`。数字商品发出后除文件损坏核实补发外，主观不满意一般不退（以销售渠道规则为准）。请仅处理您有权使用的图片。
