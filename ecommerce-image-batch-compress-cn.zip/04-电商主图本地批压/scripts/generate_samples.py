#!/usr/bin/env python3
"""生成演示主图（非商品实拍，仅色块+文字）。"""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1] / "samples"
ROOT.mkdir(parents=True, exist_ok=True)

def make(name: str, size: tuple[int, int], color: tuple[int, int, int], text: str) -> None:
    im = Image.new("RGB", size, color)
    d = ImageDraw.Draw(im)
    try:
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 36)
    except OSError:
        font = ImageFont.load_default()
    d.text((40, size[1] // 2 - 20), text, fill=(255, 255, 255), font=font)
    im.save(ROOT / name, quality=92)

make("demo_product_a.jpg", (1600, 1200), (40, 110, 180), "DEMO A 1600x1200")
make("demo_product_b.png", (1000, 1000), (180, 90, 40), "DEMO B 1000 square")
make("demo_detail_long.jpg", (900, 1800), (60, 140, 80), "DEMO DETAIL tall")
print("samples ->", ROOT)
