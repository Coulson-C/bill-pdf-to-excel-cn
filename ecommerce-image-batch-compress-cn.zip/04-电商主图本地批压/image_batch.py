#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""电商主图本地批处理：压图 + 多平台尺寸 + 可选水印。图不上传。"""
from __future__ import annotations

import argparse
import json
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

from PIL import Image, ImageDraw, ImageFont, ImageOps

SUPPORTED = {".jpg", ".jpeg", ".png", ".webp", ".bmp"}

# 内置电商预设：边长（方图）或宽（详情）
DEFAULT_PRESETS: dict[str, dict] = {
    "taobao_800": {"label": "淘宝主图800方", "mode": "square", "size": 800},
    "taobao_1200": {"label": "淘宝主图1200方", "mode": "square", "size": 1200},
    "pdd_800": {"label": "拼多多主图800方", "mode": "square", "size": 800},
    "jd_800": {"label": "京东主图800方", "mode": "square", "size": 800},
    "douyin_800": {"label": "抖店主图800方", "mode": "square", "size": 800},
    "detail_750": {"label": "详情宽750", "mode": "width", "size": 750},
    "portrait_3x4_900": {"label": "竖图3:4宽900", "mode": "ratio", "w": 900, "h": 1200},
}


@dataclass
class JobResult:
    src: Path
    outs: list[Path]
    note: str = ""


def load_presets(path: Path | None) -> dict:
    if path and path.is_file():
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            raise SystemExit("预设 JSON 必须是对象 {name: {...}}")
        return data
    return DEFAULT_PRESETS


def iter_images(folder: Path, recursive: bool) -> Iterable[Path]:
    if recursive:
        files = folder.rglob("*")
    else:
        files = folder.glob("*")
    for p in files:
        if p.is_file() and p.suffix.lower() in SUPPORTED:
            yield p


def fit_canvas(im: Image.Image, mode: str, size: int | None = None, w: int | None = None, h: int | None = None) -> Image.Image:
    """按预设生成画布：方图居中裁切/填充；宽约束等比缩放；固定比例。背景白。"""
    im = ImageOps.exif_transpose(im)
    if im.mode not in ("RGB", "RGBA"):
        im = im.convert("RGBA" if "A" in im.getbands() else "RGB")

    if mode == "square":
        assert size
        # 短边放大或长边缩小后居中裁成方图
        side = size
        src = im.convert("RGBA")
        # cover: 填满方框再裁
        ratio = max(side / src.width, side / src.height)
        nw, nh = int(src.width * ratio + 0.5), int(src.height * ratio + 0.5)
        src = src.resize((max(nw, 1), max(nh, 1)), Image.Resampling.LANCZOS)
        left = (src.width - side) // 2
        top = (src.height - side) // 2
        src = src.crop((left, top, left + side, top + side))
        bg = Image.new("RGB", (side, side), (255, 255, 255))
        if src.mode == "RGBA":
            bg.paste(src, (0, 0), src)
        else:
            bg.paste(src.convert("RGB"), (0, 0))
        return bg

    if mode == "width":
        assert size
        if im.width == size:
            out = im.convert("RGB") if im.mode != "RGB" else im.copy()
            return out
        nh = max(1, int(im.height * (size / im.width) + 0.5))
        return im.convert("RGB").resize((size, nh), Image.Resampling.LANCZOS)

    if mode == "ratio":
        assert w and h
        src = im.convert("RGBA")
        ratio = max(w / src.width, h / src.height)
        nw, nh = int(src.width * ratio + 0.5), int(src.height * ratio + 0.5)
        src = src.resize((max(nw, 1), max(nh, 1)), Image.Resampling.LANCZOS)
        left = (src.width - w) // 2
        top = (src.height - h) // 2
        src = src.crop((left, top, left + w, top + h))
        bg = Image.new("RGB", (w, h), (255, 255, 255))
        bg.paste(src, (0, 0), src if src.mode == "RGBA" else None)
        return bg

    raise ValueError(f"未知 mode: {mode}")


def apply_text_watermark(
    im: Image.Image,
    text: str,
    opacity: int = 90,
    position: str = "bottom-right",
) -> Image.Image:
    if not text:
        return im
    base = im.convert("RGBA")
    overlay = Image.new("RGBA", base.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay)
    # 默认字体；无 TTF 时用 Pillow 内置
    try:
        font = ImageFont.truetype("DejaVuSans.ttf", max(14, base.width // 40))
    except OSError:
        try:
            font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", max(14, base.width // 40))
        except OSError:
            font = ImageFont.load_default()
    bbox = draw.textbbox((0, 0), text, font=font)
    tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
    margin = max(8, base.width // 80)
    pos_map = {
        "bottom-right": (base.width - tw - margin, base.height - th - margin),
        "bottom-left": (margin, base.height - th - margin),
        "top-right": (base.width - tw - margin, margin),
        "top-left": (margin, margin),
        "center": ((base.width - tw) // 2, (base.height - th) // 2),
    }
    xy = pos_map.get(position, pos_map["bottom-right"])
    # 半透明白底条 + 深色字，可读性更好
    pad = 4
    draw.rectangle(
        [xy[0] - pad, xy[1] - pad, xy[0] + tw + pad, xy[1] + th + pad],
        fill=(255, 255, 255, min(180, opacity + 40)),
    )
    draw.text(xy, text, fill=(30, 30, 30, min(255, opacity + 100)), font=font)
    return Image.alpha_composite(base, overlay).convert("RGB")


def save_with_target_kb(
    im: Image.Image,
    dest: Path,
    fmt: str,
    quality: int,
    max_kb: int | None,
) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    fmt_u = fmt.upper()
    if fmt_u == "JPG":
        fmt_u = "JPEG"
    if max_kb is None or fmt_u not in ("JPEG", "WEBP"):
        params = {}
        if fmt_u in ("JPEG", "WEBP"):
            params["quality"] = quality
            params["optimize"] = True
        if fmt_u == "JPEG":
            im.convert("RGB").save(dest, format=fmt_u, **params)
        else:
            im.save(dest, format=fmt_u, **params)
        return

    # 二分质量逼近目标体积
    lo, hi = 40, min(95, quality)
    best = None
    for _ in range(8):
        mid = (lo + hi) // 2
        buf_path = dest
        im.convert("RGB").save(buf_path, format=fmt_u, quality=mid, optimize=True)
        size_kb = buf_path.stat().st_size / 1024
        best = mid
        if size_kb > max_kb:
            hi = mid - 1
        else:
            lo = mid + 1
    if best is not None:
        im.convert("RGB").save(dest, format=fmt_u, quality=best, optimize=True)


def process_one(
    src: Path,
    out_root: Path,
    presets: dict,
    quality: int,
    max_kb: int | None,
    fmt: str,
    watermark: str,
    wm_pos: str,
    keep_name: bool,
) -> JobResult:
    outs: list[Path] = []
    with Image.open(src) as raw:
        for key, cfg in presets.items():
            mode = cfg.get("mode", "square")
            label = cfg.get("label", key)
            fitted = fit_canvas(
                raw,
                mode=mode,
                size=cfg.get("size"),
                w=cfg.get("w"),
                h=cfg.get("h"),
            )
            if watermark:
                fitted = apply_text_watermark(fitted, watermark, position=wm_pos)
            stem = src.stem if keep_name else f"{src.stem}_{key}"
            sub = out_root / key
            ext = ".jpg" if fmt.lower() in ("jpg", "jpeg") else f".{fmt.lower()}"
            dest = sub / f"{stem}{ext}"
            save_with_target_kb(fitted, dest, fmt, quality, max_kb)
            outs.append(dest)
    return JobResult(src=src, outs=outs, note="ok")


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(
        description="电商主图本地批处理：压图 + 多平台尺寸 + 可选水印（不上传）"
    )
    ap.add_argument("input_dir", type=Path, help="源图文件夹")
    ap.add_argument("-o", "--out", type=Path, default=Path("out"), help="输出根目录（默认 out/）")
    ap.add_argument("--presets", type=Path, default=None, help="自定义预设 JSON；默认内置淘宝/拼多多等")
    ap.add_argument("--only", nargs="*", default=None, help="只跑指定预设 key，如 taobao_800 detail_750")
    ap.add_argument("--quality", type=int, default=82, help="JPEG/WebP 质量 1-95（默认 82）")
    ap.add_argument("--max-kb", type=int, default=None, help="单张目标体积上限 KB（可选，逼近压缩）")
    ap.add_argument("--format", choices=["jpg", "png", "webp"], default="jpg", help="输出格式")
    ap.add_argument("--watermark", default="", help="文字水印（空=不加）")
    ap.add_argument("--wm-pos", default="bottom-right", choices=["bottom-right", "bottom-left", "top-right", "top-left", "center"])
    ap.add_argument("--recursive", action="store_true", help="递归子目录")
    ap.add_argument("--keep-name", action="store_true", help="输出文件名保持源名（各预设进不同子文件夹）")
    args = ap.parse_args(argv)

    if not args.input_dir.is_dir():
        print(f"找不到输入目录: {args.input_dir}", file=sys.stderr)
        return 2

    presets = load_presets(args.presets)
    if args.only:
        missing = [k for k in args.only if k not in presets]
        if missing:
            print(f"未知预设: {missing}", file=sys.stderr)
            return 2
        presets = {k: presets[k] for k in args.only}

    images = list(iter_images(args.input_dir, args.recursive))
    if not images:
        print("未找到 jpg/png/webp/bmp 图片", file=sys.stderr)
        return 1

    args.out.mkdir(parents=True, exist_ok=True)
    # 原图不改动：只写 out/
    ok = 0
    for src in images:
        try:
            r = process_one(
                src,
                args.out,
                presets,
                args.quality,
                args.max_kb,
                args.format,
                args.watermark,
                args.wm_pos,
                args.keep_name or True,
            )
            ok += 1
            print(f"[OK] {src.name} → {len(r.outs)} 张")
        except Exception as e:  # noqa: BLE001 — 批处理继续
            print(f"[FAIL] {src}: {e}", file=sys.stderr)

    print(f"完成：{ok}/{len(images)} · 输出目录 {args.out.resolve()}")
    print("说明：源文件夹内原图未修改；请打开各预设子文件夹检查。")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
