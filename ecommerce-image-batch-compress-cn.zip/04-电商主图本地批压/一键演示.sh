#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 -m venv .venv
# shellcheck disable=SC1091
source .venv/bin/activate
pip install -r requirements.txt
python scripts/generate_samples.py
python image_batch.py samples -o out --presets presets/ecommerce_cn.json --quality 80 --max-kb 300 --watermark "仅供店铺演示" --keep-name
echo "完成：查看 out/ 下各平台子文件夹；samples/ 原图未改动。"
