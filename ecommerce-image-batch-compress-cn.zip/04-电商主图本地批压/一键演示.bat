@echo off
chcp 65001 >nul
cd /d "%~dp0"
python -m venv .venv
call .venv\Scripts\activate.bat
pip install -r requirements.txt
python scripts\generate_samples.py
python image_batch.py samples -o out --presets presets\ecommerce_cn.json --quality 80 --max-kb 300 --watermark "仅供店铺演示" --keep-name
echo Done. See out\ folders. Originals in samples\ untouched.
pause
