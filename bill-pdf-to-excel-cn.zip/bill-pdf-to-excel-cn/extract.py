#!/usr/bin/env python3
"""PDF text → CSV extractor for SettleSheet samples.

Layouts (auto-detect):
  - bank_checking   — original Northbridge synthetic
  - paypal_like     — original PayPal-like SAMPLE activity
  - chase_like      — MM/DD | desc | signed amount | balance
  - bofa_like       — sectioned deposits/withdrawals, unsigned amounts
  - wells_like      — date | check | desc | credits | debits | ending daily bal

Text-layer only. Layout detect + legacy bank/paypal via pypdf text;
Chase/BofA/Wells column assignment via pdfminer.six x/y clustering (extract_xy).
No OCR.
"""

from __future__ import annotations

import argparse
import csv
import re
import sys
from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation
from pathlib import Path

from pypdf import PdfReader

from extract_xy import (
    assign_wells_money,
    bofa_amount_centroid,
    chase_column_centroids,
    iter_text_lines,
    money_tokens,
    signed_amount_from_token,
    text_before_money,
    wells_column_centroids,
)

MONEY_RE = re.compile(r"^([+-]?)\$?([0-9,]+\.\d{2})$")
AMT_TOKEN = r"[+-]?\$?[0-9,]+\.\d{2}"


def parse_money(s: str) -> Decimal:
    s = s.strip().replace(" ", "")
    m = MONEY_RE.match(s)
    if not m:
        s2 = s.replace("$", "")
        sign = Decimal("-1") if s2.startswith("-") else Decimal("1")
        s2 = s2.lstrip("+-")
        return sign * Decimal(s2.replace(",", ""))
    sign = Decimal("-1") if m.group(1) == "-" else Decimal("1")
    return sign * Decimal(m.group(2).replace(",", ""))


def pdf_text(path: Path) -> str:
    reader = PdfReader(str(path))
    return "\n".join((page.extract_text() or "") for page in reader.pages)


def detect_layout(text: str) -> str:
    """Heuristic layout detection — order matters (more specific first)."""
    if "NORTHBRIDGE BANK" in text and "Checking Account Statement" in text:
        return "bank_checking"
    if "Monthly Activity Statement (SAMPLE)" in text and "SAMPLE-TXN-" in text:
        return "paypal_like"
    # Explicit DEMO markers from generate_realish.py
    if "Chase-like" in text or "RIVERWAY BANK" in text:
        return "chase_like"
    if "BofA-like" in text or (
        "Deposits and other additions" in text
        and "Withdrawals and other subtractions" in text
    ):
        return "bofa_like"
    if "Wells-like" in text or (
        re.search(r"Credits\s+Debits", text) and "Transaction history" in text
    ):
        return "wells_like"
    if "Deposits/Credits" in text and "Withdrawals/Debits" in text:
        return "wells_like"
    # Fallbacks without DEMO markers
    if "TRANSACTION DETAIL" in text and re.search(
        r"^\d{1,2}/\d{1,2}\s+.+\s+[+-]?[0-9,]+\.\d{2}\s+[0-9,]+\.\d{2}\s*$",
        text,
        re.M,
    ):
        return "chase_like"
    raise ValueError(
        "Unsupported layout. Supported: bank_checking, paypal_like, "
        "chase_like, bofa_like, wells_like (text-layer PDFs only)."
    )


# --- Original Day-2 patterns -------------------------------------------------

BANK_TXN_RE = re.compile(
    r"^(?P<date>\d{4}-\d{2}-\d{2})\s+"
    r"(?P<desc>.+?)\s+"
    r"(?P<amount>[+-][0-9,]+\.\d{2})\s+"
    r"(?P<balance>[0-9,]+\.\d{2})\s*$"
)

PP_TXN_RE = re.compile(
    r"^(?P<date>\d{4}-\d{2}-\d{2})\s+"
    r"(?P<type>Payment|Refund|Fee|Transfer)\s+"
    r"(?P<gross>-?[0-9,]+\.\d{2})\s+"
    r"(?P<fee>-?[0-9,]+\.\d{2})\s+"
    r"(?P<net>-?[0-9,]+\.\d{2})\s+"
    r"(?P<txn>SAMPLE-TXN-\d+)\s*"
    r"(?P<name>.*)$"
)

SUMMARY_RE = {
    "opening": re.compile(
        r"(?:Opening balance|Beginning [Bb]alance(?:\s+on\s+[\d/]+)?)\s*:?\s*\$([0-9,]+\.\d{2})",
        re.I,
    ),
    "closing": re.compile(
        r"(?:Closing balance|Ending [Bb]alance(?:\s+on\s+[\d/]+)?)\s*:?\s*\$([0-9,]+\.\d{2})",
        re.I,
    ),
    "deposits": re.compile(
        r"Total deposits(?:\s*/\s*credits|\s+and\s+other\s+additions)?\s*:?\s*\$([0-9,]+\.\d{2})",
        re.I,
    ),
    "withdrawals": re.compile(
        r"Total withdrawals(?:\s*/\s*debits|\s+and\s+other\s+subtractions)?\s*:?\s*\$([0-9,]+\.\d{2})",
        re.I,
    ),
    "pp_gross": re.compile(r"Total gross:\s*\$([+-]?[0-9,]+\.\d{2})", re.I),
    "pp_fee": re.compile(r"Total fees:\s*\$([+-]?[0-9,]+\.\d{2})", re.I),
    "pp_net": re.compile(r"Total net:\s*\$([+-]?[0-9,]+\.\d{2})", re.I),
}


@dataclass
class ExtractResult:
    layout: str
    rows: list[dict]
    summary: dict
    fieldnames: list[str]
    notes: list[str] = field(default_factory=list)


def _bank_summary(text: str) -> dict:
    summary = {}
    for key, rx in SUMMARY_RE.items():
        if key.startswith("pp_"):
            continue
        m = rx.search(text)
        if m:
            summary[key] = m.group(1).replace(",", "")
    # Chase summary lines without colon: "Beginning Balance   $4,521.37"
    if "opening" not in summary:
        m = re.search(r"Beginning Balance\s+\$([0-9,]+\.\d{2})", text)
        if m:
            summary["opening"] = m.group(1).replace(",", "")
    if "closing" not in summary:
        m = re.search(r"Ending Balance\s+\$([0-9,]+\.\d{2})", text)
        if m:
            summary["closing"] = m.group(1).replace(",", "")
    # Wells-style: Beginning balance on 9/1: $...
    if "deposits" not in summary:
        m = re.search(r"Deposits/Credits:\s*\$([0-9,]+\.\d{2})", text)
        if m:
            summary["deposits"] = m.group(1).replace(",", "")
    if "withdrawals" not in summary:
        m = re.search(r"Withdrawals/Debits:\s*\$([0-9,]+\.\d{2})", text)
        if m:
            summary["withdrawals"] = m.group(1).replace(",", "")
    return summary


def _period_year(text: str, fallback: int = 2026) -> int:
    """Recover statement year from common US period headers."""
    patterns = [
        r"(January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2},\s+(\d{4})",
        r"(?:through|to|[-–])\s*(?:January|February|March|April|May|June|July|August|September|October|November|December)?\s*\d{1,2},?\s*(\d{4})",
        r"period:\s*\d{1,2}/\d{1,2}/(\d{2,4})",
        r"period:\s*\d{1,2}/\d{1,2}/(\d{4})",
        r"to\s+\d{1,2}/\d{1,2}/(\d{4})",
        r"\b(20\d{2})\b",
    ]
    for pat in patterns:
        m = re.search(pat, text, re.I)
        if not m:
            continue
        g = m.groups()[-1]
        if len(g) == 2:
            return 2000 + int(g)
        if g.isdigit() and len(g) == 4:
            return int(g)
        # month-name match: year is last group
        for grp in reversed(m.groups()):
            if grp and grp.isdigit() and len(grp) == 4:
                return int(grp)
    return fallback


def _iso_from_mmdd(mmdd: str, year: int) -> str:
    mm, dd = mmdd.split("/")
    return f"{year}-{int(mm):02d}-{int(dd):02d}"


def _iso_from_mmddyy(mmddyy: str) -> str:
    mm, dd, yy = mmddyy.split("/")
    year = 2000 + int(yy) if len(yy) == 2 else int(yy)
    return f"{year}-{int(mm):02d}-{int(dd):02d}"


def extract_bank(text: str) -> ExtractResult:
    rows = []
    for raw in text.splitlines():
        line = raw.strip()
        m = BANK_TXN_RE.match(line)
        if not m:
            continue
        amount = parse_money(m.group("amount"))
        balance = parse_money(m.group("balance"))
        rows.append(
            {
                "date": m.group("date"),
                "description": m.group("desc").strip(),
                "amount": f"{amount:.2f}",
                "balance": f"{balance:.2f}",
            }
        )
    return ExtractResult(
        layout="bank_checking",
        rows=rows,
        summary=_bank_summary(text),
        fieldnames=["date", "description", "amount", "balance"],
    )


def extract_paypal(text: str) -> ExtractResult:
    rows = []
    for raw in text.splitlines():
        line = raw.strip()
        m = PP_TXN_RE.match(line)
        if not m:
            continue
        rows.append(
            {
                "date": m.group("date"),
                "name": m.group("name").strip(),
                "type": m.group("type"),
                "gross": f"{parse_money(m.group('gross')):.2f}",
                "fee": f"{parse_money(m.group('fee')):.2f}",
                "net": f"{parse_money(m.group('net')):.2f}",
                "txn_id": m.group("txn"),
                "currency": "USD",
            }
        )
    summary = {}
    for key in ("pp_gross", "pp_fee", "pp_net"):
        m = SUMMARY_RE[key].search(text)
        if m:
            summary[key.replace("pp_", "total_")] = m.group(1).replace(",", "")
    return ExtractResult(
        layout="paypal_like",
        rows=rows,
        summary=summary,
        fieldnames=["date", "name", "type", "gross", "fee", "net", "txn_id", "currency"],
    )


# --- Chase / BofA / Wells via pdfminer x/y clustering (see extract_xy.py) ---

CHASE_TXN_RE = re.compile(  # kept for fallback / detect helpers
    r"^(?P<date>\d{1,2}/\d{1,2})\s+"
    r"(?P<desc>.+?)\s+"
    r"(?P<amount>[+-]?[0-9,]+\.\d{2})\s+"
    r"(?P<balance>[0-9,]+\.\d{2})\s*$"
)

BOFA_TXN_RE = re.compile(
    r"^(?P<date>\d{1,2}/\d{1,2}/\d{2,4})\s+"
    r"(?P<desc>.+?)\s+"
    r"(?P<amount>[0-9,]+\.\d{2})\s*$"
)

BOFA_DAILY_RE = re.compile(
    r"^(?P<date>\d{1,2}/\d{1,2}/\d{2,4})\s+(?P<balance>[0-9,]+\.\d{2})\s*$"
)


def extract_chase_like(pdf_path: Path, text: str) -> ExtractResult:
    """Chase-like: amount + balance columns via x-clustering; sign from glyphs."""
    year = _period_year(text)
    notes = [f"period_year={year}", "column_mode=pdfminer_xy_cluster"]
    lines = list(iter_text_lines(pdf_path))
    # Candidate txn lines: start with MM/DD and have >=2 money tokens
    candidates = []
    for ln in lines:
        stripped = ln.text.strip()
        if not stripped or stripped.upper().startswith("DATE"):
            continue
        if "Beginning Balance" in stripped or "Ending Balance" in stripped:
            continue
        if "TRANSACTION DETAIL" in stripped or "CHECKING SUMMARY" in stripped:
            continue
        if stripped.startswith("END"):
            continue
        toks = money_tokens(ln)
        if len(toks) < 2:
            continue
        if not re.match(r"^\d{1,2}/\d{1,2}\b", stripped):
            continue
        candidates.append(ln)

    cols = chase_column_centroids(candidates)
    notes.append(
        f"xy_centroids amount={cols['amount']:.1f} balance={cols['balance']:.1f}"
    )
    mid = (cols["amount"] + cols["balance"]) / 2.0
    rows = []
    for ln in candidates:
        toks = money_tokens(ln)
        amount_toks = [t for t in toks if t.xc < mid]
        bal_toks = [t for t in toks if t.xc >= mid]
        if not amount_toks or not bal_toks:
            # nearest-centroid fallback
            amt_tok = min(toks, key=lambda t: abs(t.xc - cols["amount"]))
            bal_tok = min(toks, key=lambda t: abs(t.xc - cols["balance"]))
            if amt_tok is bal_tok and len(toks) >= 2:
                ordered = sorted(toks, key=lambda t: t.xc)
                amt_tok, bal_tok = ordered[0], ordered[-1]
        else:
            amt_tok = amount_toks[0]
            bal_tok = bal_toks[-1]

        before = text_before_money(ln, amt_tok)
        dm = re.match(r"^(\d{1,2}/\d{1,2})\s+(.*)$", before.strip())
        if not dm:
            continue
        date_s, desc = dm.group(1), dm.group(2).strip()
        if desc.lower() in {"description", "beginning balance", "ending balance"}:
            continue
        amount = signed_amount_from_token(ln, amt_tok)
        balance = abs(bal_tok.value)
        rows.append(
            {
                "date": _iso_from_mmdd(date_s, year),
                "description": desc,
                "amount": f"{amount:.2f}",
                "balance": f"{balance:.2f}",
            }
        )
    return ExtractResult(
        layout="chase_like",
        rows=rows,
        summary=_bank_summary(text),
        fieldnames=["date", "description", "amount", "balance"],
        notes=notes,
    )


def extract_bofa_like(pdf_path: Path, text: str) -> ExtractResult:
    """BofA-like: section headers for sign; amount column via x-clustering."""
    notes: list[str] = ["column_mode=pdfminer_xy_cluster"]
    lines = list(iter_text_lines(pdf_path))
    section: str | None = None
    daily: dict[str, str] = {}
    raw_rows: list[dict] = []

    # Pre-scan section txn candidates to learn amount centroid
    section_probe: list = []
    probe_section = None
    for ln in lines:
        low = ln.text.strip().lower()
        if low.startswith("deposits and other additions") and "total" not in low:
            probe_section = "credit"
            continue
        if low.startswith("withdrawals and other subtractions") and "total" not in low:
            probe_section = "debit"
            continue
        if low.startswith("daily balance summary"):
            probe_section = "daily"
            continue
        if probe_section in ("credit", "debit") and money_tokens(ln):
            if re.match(r"^\d{1,2}/\d{1,2}/\d{2,4}\b", ln.text.strip()):
                section_probe.append(ln)

    amt_xc = bofa_amount_centroid(section_probe)
    notes.append(f"xy_amount_centroid={amt_xc:.1f}")

    for ln in lines:
        line = ln.text.strip()
        if not line:
            continue
        low = line.lower()
        if low.startswith("deposits and other additions") and "total" not in low:
            section = "credit"
            continue
        if low.startswith("withdrawals and other subtractions") and "total" not in low:
            section = "debit"
            continue
        if low.startswith("daily balance summary"):
            section = "daily"
            continue
        if low.startswith("date") and "description" in low:
            continue
        if low.startswith("total ") or low.startswith("account summary") or low.startswith("beginning"):
            continue
        if low.startswith("ending balance") or low.startswith("end —") or low.startswith("end -"):
            continue

        toks = money_tokens(ln)
        if section in ("credit", "debit"):
            if not toks:
                continue
            if not re.match(r"^\d{1,2}/\d{1,2}/\d{2,4}\b", line):
                continue
            # Pick money token nearest amount centroid (ignore stray $ in desc)
            tok = min(toks, key=lambda t: abs(t.xc - amt_xc))
            # Prefer rightmost if multiple equally plausible
            right = [t for t in toks if abs(t.xc - amt_xc) < 30]
            if right:
                tok = max(right, key=lambda t: t.xc)
            before = text_before_money(ln, tok)
            dm = re.match(r"^(\d{1,2}/\d{1,2}/\d{2,4})\s+(.*)$", before.strip())
            if not dm:
                # Fallback regex on plain text
                m = BOFA_TXN_RE.match(line)
                if not m:
                    continue
                iso = _iso_from_mmddyy(m.group("date"))
                desc = m.group("desc").strip()
                amt = parse_money(m.group("amount"))
            else:
                iso = _iso_from_mmddyy(dm.group(1))
                desc = dm.group(2).strip()
                amt = abs(tok.value)
            if section == "debit":
                amt = -abs(amt)
            else:
                amt = abs(amt)
            raw_rows.append(
                {
                    "date": iso,
                    "description": desc,
                    "amount": f"{amt:.2f}",
                    "balance": "",
                    "section": section,
                }
            )
        elif section == "daily":
            if not toks:
                continue
            m = BOFA_DAILY_RE.match(line)
            if m:
                daily[_iso_from_mmddyy(m.group("date"))] = f"{parse_money(m.group('balance')):.2f}"
            else:
                dm = re.match(r"^(\d{1,2}/\d{1,2}/\d{2,4})\b", line)
                if dm and toks:
                    daily[_iso_from_mmddyy(dm.group(1))] = f"{abs(toks[-1].value):.2f}"

    summary = _bank_summary(text)
    opening = Decimal(summary["opening"]) if "opening" in summary else None
    for i, r in enumerate(raw_rows):
        r["_i"] = i
    raw_rows.sort(key=lambda r: (r["date"], r["_i"]))

    if opening is not None:
        bal = opening
        for r in raw_rows:
            bal = (bal + Decimal(r["amount"])).quantize(Decimal("0.01"))
            r["balance"] = f"{bal:.2f}"
            del r["_i"]
            del r["section"]
        notes.append("balances reconstructed from opening + signed section amounts")
        mismatches = 0
        last_by_day: dict[str, str] = {}
        for r in raw_rows:
            last_by_day[r["date"]] = r["balance"]
        for d, expected in daily.items():
            got = last_by_day.get(d)
            if got and got != expected:
                mismatches += 1
        if daily:
            notes.append(
                f"daily_summary_days={len(daily)} mismatches_vs_reconstructed={mismatches}"
            )
    else:
        for r in raw_rows:
            r.pop("_i", None)
            r.pop("section", None)
            if r["date"] in daily:
                r["balance"] = daily[r["date"]]
        notes.append("no opening balance; partial balances from daily summary only")

    return ExtractResult(
        layout="bofa_like",
        rows=[{k: r[k] for k in ("date", "description", "amount", "balance")} for r in raw_rows],
        summary=summary,
        fieldnames=["date", "description", "amount", "balance"],
        notes=notes,
    )


def extract_wells_like(pdf_path: Path, text: str) -> ExtractResult:
    """Wells-like: Credits/Debits/Bal via header anchors or money x-clustering."""
    year = _period_year(text)
    notes = [f"period_year={year}", "column_mode=pdfminer_xy_cluster"]
    summary = _bank_summary(text)
    opening = Decimal(summary["opening"]) if "opening" in summary else None

    lines = list(iter_text_lines(pdf_path))
    history: list = []
    in_history = False
    for ln in lines:
        stripped = ln.text.strip()
        if "Transaction history" in stripped:
            in_history = True
            continue
        if not in_history:
            continue
        if stripped.startswith("END"):
            break
        history.append(ln)

    hist_with_money = [
        ln
        for ln in history
        if money_tokens(ln)
        and re.match(r"^\d{1,2}/\d{1,2}\b", ln.text.strip())
        and not (ln.text.strip().startswith("Date") and "Chk" in ln.text)
    ]
    cols = wells_column_centroids(lines, hist_with_money)
    notes.append(
        "xy_centroids "
        + " ".join(f"{k}={v:.1f}" for k, v in cols.items() if not k.startswith("_") and isinstance(v, float))
    )

    rows = []
    for ln in hist_with_money:
        stripped = ln.text.strip()
        if stripped.startswith("Date") and "Chk" in stripped:
            continue
        toks = money_tokens(ln)
        if not toks:
            continue
        credit, debit, bal = assign_wells_money(toks, cols)
        # If ambiguous (credit==debit centroid) and we got credit but token sits
        # nearer a typical debit zone relative to balance, flip using midpoints.
        if cols["credit"] == cols["debit"] and credit and not debit:
            mid_db = (cols["credit"] + cols["balance"]) / 2.0
            # Heuristic: tokens left of a soft split 60% toward balance from left amount
            # Prefer: if the amount token's xc is in the right half of [credit, balance], debit.
            amt_toks = [t for t in toks if abs(t.xc - cols["balance"]) > abs(t.xc - cols["credit"])]
            if amt_toks:
                ax = amt_toks[0].xc
                if ax > cols["credit"] + 0.45 * (cols["balance"] - cols["credit"]):
                    debit = credit
                    credit = Decimal("0")

        before = text_before_money(ln, toks[0])
        dm = re.match(r"^(\d{1,2}/\d{1,2})\s+(.*)$", before.strip())
        if not dm:
            continue
        date_s = dm.group(1)
        rest_desc = dm.group(2).strip()
        check_number = ""
        desc = rest_desc
        chk_m = re.match(r"^(\d{3,6})\s+(.*)$", rest_desc)
        if chk_m:
            check_number = chk_m.group(1)
            desc = chk_m.group(2).strip()

        amount = credit - debit
        bal_s = f"{bal:.2f}" if bal is not None else ""
        rows.append(
            {
                "date": _iso_from_mmdd(date_s, year),
                "description": desc,
                "amount": f"{amount:.2f}",
                "balance": bal_s,
                "check_number": check_number,
            }
        )

    if opening is not None and rows:
        bal_run = opening
        for r in rows:
            bal_run = (bal_run + Decimal(r["amount"])).quantize(Decimal("0.01"))
            if r["balance"]:
                if Decimal(r["balance"]) != bal_run:
                    notes.append(
                        f"ending-daily bal mismatch on {r['date']}: "
                        f"printed {r['balance']} vs chain {bal_run}"
                    )
                bal_run = Decimal(r["balance"])
            else:
                r["balance"] = f"{bal_run:.2f}"
        notes.append("filled missing per-row balances from running chain")

    return ExtractResult(
        layout="wells_like",
        rows=rows,
        summary=summary,
        fieldnames=["date", "description", "amount", "balance", "check_number"],
        notes=notes,
    )



def extract(path: Path) -> ExtractResult:
    text = pdf_text(path)
    if not text.strip():
        raise ValueError(
            "No extractable text (image-only / scanned PDF). MVP is text-layer only; OCR not enabled."
        )
    layout = detect_layout(text)
    if layout == "bank_checking":
        return extract_bank(text)
    if layout == "paypal_like":
        return extract_paypal(text)
    if layout == "chase_like":
        return extract_chase_like(path, text)
    if layout == "bofa_like":
        return extract_bofa_like(path, text)
    if layout == "wells_like":
        return extract_wells_like(path, text)
    raise ValueError(f"Unhandled layout: {layout}")


def write_csv(result: ExtractResult, out_path: Path) -> None:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with out_path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=result.fieldnames, extrasaction="ignore")
        w.writeheader()
        w.writerows(result.rows)


def balance_check_bank(result: ExtractResult) -> dict:
    notes = []
    ok = True
    if not result.rows:
        return {"ok": False, "notes": ["no rows extracted"]}
    opening = result.summary.get("opening")
    try:
        if opening is not None:
            bal = Decimal(opening)
            first_amt = Decimal(result.rows[0]["amount"])
            first_bal = Decimal(result.rows[0]["balance"])
            expected_first = (bal + first_amt).quantize(Decimal("0.01"))
            if expected_first != first_bal:
                ok = False
                notes.append(
                    f"first balance mismatch: opening {opening} + {first_amt} "
                    f"!= {first_bal} (expected {expected_first})"
                )
            else:
                notes.append("opening → first balance OK")
        prev = Decimal(result.rows[0]["balance"])
        for i, row in enumerate(result.rows[1:], start=2):
            if not row.get("balance"):
                ok = False
                notes.append(f"row {i} missing balance")
                break
            amt = Decimal(row["amount"])
            bal = Decimal(row["balance"])
            exp = (prev + amt).quantize(Decimal("0.01"))
            if exp != bal:
                ok = False
                notes.append(f"row {i} balance break: prev {prev} + {amt} != {bal}")
                break
            prev = bal
        else:
            notes.append(f"running balance chain OK for {len(result.rows)} rows")

        closing = result.summary.get("closing")
        if closing is not None:
            last = Decimal(result.rows[-1]["balance"])
            if last != Decimal(closing):
                ok = False
                notes.append(f"closing mismatch: last bal {last} vs summary {closing}")
            else:
                notes.append(f"closing balance OK ({closing})")
    except (InvalidOperation, KeyError) as e:
        ok = False
        notes.append(f"balance check error: {e}")
    return {"ok": ok, "notes": notes}


def totals_check_paypal(result: ExtractResult) -> dict:
    notes = []
    ok = True
    if not result.rows:
        return {"ok": False, "notes": ["no rows extracted"]}
    gross = sum(Decimal(r["gross"]) for r in result.rows).quantize(Decimal("0.01"))
    fee = sum(Decimal(r["fee"]) for r in result.rows).quantize(Decimal("0.01"))
    net = sum(Decimal(r["net"]) for r in result.rows).quantize(Decimal("0.01"))
    for i, r in enumerate(result.rows, start=1):
        g, f, n = Decimal(r["gross"]), Decimal(r["fee"]), Decimal(r["net"])
        if (g + f).quantize(Decimal("0.01")) != n:
            ok = False
            notes.append(f"row {i} net != gross+fee: {g}+{f}!={n}")
            break
    else:
        notes.append("per-row net = gross + fee OK")
    for label, computed, key in (
        ("gross", gross, "total_gross"),
        ("fee", fee, "total_fee"),
        ("net", net, "total_net"),
    ):
        expected = result.summary.get(key)
        if expected is None:
            notes.append(f"summary {key} missing from PDF text")
            continue
        if Decimal(expected) != computed:
            ok = False
            notes.append(f"total {label} mismatch: rows {computed} vs summary {expected}")
        else:
            notes.append(f"total {label} OK ({computed})")
    return {"ok": ok, "notes": notes, "computed": {"gross": str(gross), "fee": str(fee), "net": str(net)}}


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="Extract SettleSheet sample PDFs to CSV")
    p.add_argument("pdf", type=Path, help="Input PDF path")
    p.add_argument("-o", "--output", type=Path, required=True, help="Output CSV path")
    p.add_argument("--check", action="store_true", help="Print balance/totals check")
    args = p.parse_args(argv)

    try:
        result = extract(args.pdf)
    except Exception as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 1

    write_csv(result, args.output)
    print(f"layout={result.layout} rows={len(result.rows)} -> {args.output}")
    if result.summary:
        print("summary:", result.summary)
    if result.notes:
        for n in result.notes:
            print("note:", n)

    if args.check:
        if result.layout == "paypal_like":
            chk = totals_check_paypal(result)
        else:
            chk = balance_check_bank(result)
        print("check_ok=", chk["ok"])
        for n in chk["notes"]:
            print(" -", n)
        return 0 if chk["ok"] else 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
