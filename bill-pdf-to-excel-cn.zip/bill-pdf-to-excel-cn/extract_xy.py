#!/usr/bin/env python3
"""pdfminer.six x/y geometry helpers + column clustering for bank layouts.

Replaces Courier string-position heuristics (e.g. first_money_abs < 52) with
real glyph x-coordinates clustered into Credits / Debits / Balance (etc.).
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from decimal import Decimal
from pathlib import Path
from typing import Iterable

from pdfminer.high_level import extract_pages
from pdfminer.layout import LTAnno, LTChar, LTTextLine

MONEY_RE = re.compile(r"[+-]?\$?[0-9,]+\.\d{2}")
DATE_MMDD = re.compile(r"^(\d{1,2}/\d{1,2})$")
DATE_MMDDYY = re.compile(r"^(\d{1,2}/\d{1,2}/\d{2,4})$")


@dataclass
class Glyph:
    text: str
    x0: float
    x1: float
    y0: float
    y1: float

    @property
    def xc(self) -> float:
        return (self.x0 + self.x1) / 2.0


@dataclass
class MoneyToken:
    raw: str
    value: Decimal
    x0: float
    x1: float
    xc: float
    # index into the line's reconstructed string
    start: int
    end: int


@dataclass
class GeoLine:
    text: str
    y0: float
    y1: float
    x0: float
    x1: float
    glyphs: list[Glyph] = field(default_factory=list)
    page: int = 0

    @property
    def yc(self) -> float:
        return (self.y0 + self.y1) / 2.0


def parse_money(s: str) -> Decimal:
    s = s.strip().replace(" ", "").replace("$", "")
    sign = Decimal("-1") if s.startswith("-") else Decimal("1")
    s = s.lstrip("+-")
    return sign * Decimal(s.replace(",", ""))


def iter_text_lines(path: Path) -> Iterable[GeoLine]:
    """Yield PDF text lines with per-glyph geometry (pdfminer)."""
    for page_i, page in enumerate(extract_pages(str(path))):
        yield from _walk_page(page, page_i)


def _walk_page(obj, page_i: int) -> Iterable[GeoLine]:
    if isinstance(obj, LTTextLine):
        glyphs: list[Glyph] = []
        parts: list[str] = []
        for el in obj:
            if isinstance(el, LTChar):
                g = Glyph(el.get_text(), el.x0, el.x1, el.y0, el.y1)
                glyphs.append(g)
                parts.append(g.text)
            elif isinstance(el, LTAnno):
                # Soft hyphen / space without geometry — keep in text only
                t = el.get_text()
                if t and t != "\n":
                    parts.append(t)
        text = "".join(parts).rstrip("\n")
        if not text.strip():
            return
        if glyphs:
            yield GeoLine(
                text=text,
                y0=min(g.y0 for g in glyphs),
                y1=max(g.y1 for g in glyphs),
                x0=min(g.x0 for g in glyphs),
                x1=max(g.x1 for g in glyphs),
                glyphs=glyphs,
                page=page_i,
            )
        else:
            yield GeoLine(
                text=text,
                y0=obj.y0,
                y1=obj.y1,
                x0=obj.x0,
                x1=obj.x1,
                glyphs=[],
                page=page_i,
            )
        return
    if hasattr(obj, "__iter__") and not isinstance(obj, (LTChar, LTAnno)):
        for child in obj:
            yield from _walk_page(child, page_i)


def _rebuild_string_with_glyph_map(glyphs: list[Glyph]) -> tuple[str, list[Glyph | None]]:
    """Build string from glyphs only (geometry-backed). LTAnno gaps omitted."""
    s_parts: list[str] = []
    idx_map: list[Glyph | None] = []
    for g in glyphs:
        for ch in g.text:
            s_parts.append(ch)
            idx_map.append(g)
    return "".join(s_parts), idx_map


def money_tokens(line: GeoLine) -> list[MoneyToken]:
    """Find money amounts on a line and attach x-geometry from glyphs."""
    if not line.glyphs:
        # Fallback: no geometry — return tokens with xc=0
        out = []
        for m in MONEY_RE.finditer(line.text):
            out.append(
                MoneyToken(
                    raw=m.group(0),
                    value=parse_money(m.group(0)),
                    x0=0.0,
                    x1=0.0,
                    xc=0.0,
                    start=m.start(),
                    end=m.end(),
                )
            )
        return out

    s, idx_map = _rebuild_string_with_glyph_map(line.glyphs)
    # Also search original line.text in case LTAnno inserted spaces differently;
    # prefer glyph string for geometry.
    out: list[MoneyToken] = []
    for m in MONEY_RE.finditer(s):
        sub = [idx_map[i] for i in range(m.start(), m.end()) if idx_map[i] is not None]
        if not sub:
            continue
        x0 = sub[0].x0
        x1 = sub[-1].x1
        out.append(
            MoneyToken(
                raw=m.group(0),
                value=parse_money(m.group(0)),
                x0=x0,
                x1=x1,
                xc=(x0 + x1) / 2.0,
                start=m.start(),
                end=m.end(),
            )
        )
    return out


def cluster_1d(values: list[float], gap: float = 18.0) -> list[float]:
    """Gap-based 1D clustering → sorted cluster centroids (mean of each run).

    Sort values; start a new cluster when consecutive gap > `gap` (PDF points).
    """
    if not values:
        return []
    xs = sorted(values)
    clusters: list[list[float]] = [[xs[0]]]
    for x in xs[1:]:
        if x - clusters[-1][-1] > gap:
            clusters.append([x])
        else:
            clusters[-1].append(x)
    return [sum(c) / len(c) for c in clusters]


def nearest_cluster(x: float, centroids: list[float]) -> int:
    if not centroids:
        return -1
    best_i, best_d = 0, abs(x - centroids[0])
    for i, c in enumerate(centroids[1:], start=1):
        d = abs(x - c)
        if d < best_d:
            best_i, best_d = i, d
    return best_i


def find_header_anchors(lines: list[GeoLine], labels: list[str]) -> dict[str, float] | None:
    """Find a header line containing all labels; return label → x-center."""
    for line in lines:
        low = line.text.lower()
        if not all(lab.lower() in low for lab in labels):
            continue
        anchors: dict[str, float] = {}
        s, idx_map = _rebuild_string_with_glyph_map(line.glyphs) if line.glyphs else (line.text, [])
        search_in = s if line.glyphs else line.text
        ok = True
        for lab in labels:
            # case-sensitive first, then casefold
            i = search_in.find(lab)
            if i < 0:
                i = search_in.lower().find(lab.lower())
            if i < 0 or not line.glyphs:
                ok = False
                break
            sub = [idx_map[j] for j in range(i, min(i + len(lab), len(idx_map))) if idx_map[j]]
            if not sub:
                ok = False
                break
            anchors[lab] = (sub[0].x0 + sub[-1].x1) / 2.0
        if ok and len(anchors) == len(labels):
            return anchors
    return None


def wells_column_centroids(lines: list[GeoLine], history_lines: list[GeoLine]) -> dict[str, float]:
    """Resolve Credits / Debits / Bal x-centroids via header anchors or money clustering."""
    anchors = find_header_anchors(lines, ["Credits", "Debits", "Bal"])
    if anchors:
        return {
            "credit": anchors["Credits"],
            "debit": anchors["Debits"],
            "balance": anchors["Bal"],
        }

    # Cluster money x-centers from transaction-looking rows
    xs: list[float] = []
    for line in history_lines:
        for tok in money_tokens(line):
            xs.append(tok.xc)
    cents = cluster_1d(xs, gap=18.0)
    if len(cents) >= 3:
        # leftmost credit, middle debit, rightmost balance
        return {"credit": cents[0], "debit": cents[1], "balance": cents[-1]}
    if len(cents) == 2:
        # amount + balance only (can't split credit/debit by x alone)
        mid = (cents[0] + cents[1]) / 2.0
        return {"credit": cents[0], "debit": cents[0], "balance": cents[1], "_ambiguous_amount": mid}
    if len(cents) == 1:
        return {"credit": cents[0], "debit": cents[0], "balance": cents[0] + 40.0}
    return {"credit": 220.0, "debit": 270.0, "balance": 320.0}


def assign_wells_money(
    tokens: list[MoneyToken], cols: dict[str, float]
) -> tuple[Decimal, Decimal, Decimal | None]:
    """Assign money tokens to credit / debit / balance by nearest x-centroid."""
    credit = Decimal("0")
    debit = Decimal("0")
    bal: Decimal | None = None
    credit_c = cols["credit"]
    debit_c = cols["debit"]
    bal_c = cols["balance"]
    # Boundary midpoints
    mid_cd = (credit_c + debit_c) / 2.0 if credit_c != debit_c else credit_c - 0.1
    mid_db = (debit_c + bal_c) / 2.0

    for tok in tokens:
        x = tok.xc
        # Prefer 3-way nearest among named centroids
        named = [("credit", credit_c), ("debit", debit_c), ("balance", bal_c)]
        label = min(named, key=lambda kv: abs(x - kv[1]))[0]
        # If credit==debit centroid (ambiguous), use sign of value / later logic
        if credit_c == debit_c and label != "balance":
            # fall through: treat as amount column; caller may need section — for Wells use
            # position relative to balance only: left of mid_db → amount; decide credit vs debit
            # by whether x is left of a soft "debit zone" OR by value placement vs header gap
            if x < mid_db:
                # Without separate credit/debit anchors, leave as unsigned amount in credit
                # and let a secondary rule flip — better: use relative to page, but here
                # split by: if closer to left edge of amount zone → credit else debit.
                # With 2 clusters only both amounts share same xc band — IMPOSSIBLE to
                # distinguish by x. Fall back: put in credit if we only have that band;
                # extract_wells_xy will use token count heuristics + bal.
                label = "credit"
        if label == "credit":
            credit += abs(tok.value)
        elif label == "debit":
            debit += abs(tok.value)
        else:
            bal = abs(tok.value)
    return credit, debit, bal


def chase_column_centroids(txn_lines: list[GeoLine]) -> dict[str, float]:
    xs: list[float] = []
    for line in txn_lines:
        for tok in money_tokens(line):
            xs.append(tok.xc)
    cents = cluster_1d(xs, gap=20.0)
    if len(cents) >= 2:
        return {"amount": cents[0], "balance": cents[-1]}
    if len(cents) == 1:
        return {"amount": cents[0], "balance": cents[0] + 50.0}
    return {"amount": 300.0, "balance": 355.0}


def bofa_amount_centroid(txn_lines: list[GeoLine]) -> float:
    xs: list[float] = []
    for line in txn_lines:
        for tok in money_tokens(line):
            xs.append(tok.xc)
    cents = cluster_1d(xs, gap=25.0)
    # Prefer the rightmost (amount column); dates rarely have .00 money
    return cents[-1] if cents else 320.0


def text_before_money(line: GeoLine, first_tok: MoneyToken) -> str:
    """Description / date region left of the first money token (glyph string)."""
    if not line.glyphs:
        m = MONEY_RE.search(line.text)
        return line.text[: m.start()].strip() if m else line.text.strip()
    s, _ = _rebuild_string_with_glyph_map(line.glyphs)
    return s[: first_tok.start].strip()


def signed_amount_from_token(line: GeoLine, tok: MoneyToken) -> Decimal:
    """Chase-like: detect leading minus near the amount glyph."""
    if tok.raw.lstrip().startswith("-") or tok.value < 0:
        return -abs(tok.value)
    # Peek a few glyphs left of token for '-'
    if line.glyphs:
        s, idx_map = _rebuild_string_with_glyph_map(line.glyphs)
        left = s[max(0, tok.start - 3) : tok.start]
        if "-" in left:
            return -abs(tok.value)
    # Also check original line text around the amount
    idx = line.text.find(tok.raw)
    if idx > 0 and line.text[max(0, idx - 2) : idx].find("-") >= 0:
        return -abs(tok.value)
    return abs(tok.value)


__all__ = [
    "GeoLine",
    "MoneyToken",
    "iter_text_lines",
    "money_tokens",
    "cluster_1d",
    "nearest_cluster",
    "find_header_anchors",
    "wells_column_centroids",
    "assign_wells_money",
    "chase_column_centroids",
    "bofa_amount_centroid",
    "text_before_money",
    "signed_amount_from_token",
    "parse_money",
]
