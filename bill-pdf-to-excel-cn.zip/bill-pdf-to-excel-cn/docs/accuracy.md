# Parser accuracy — Day-2 (synthetic layouts only)

- **Date**: 2026-10-31 (Asia/Shanghai)
- **Runtime**: `/workspace/venture-auto-top1/.venv` (`reportlab` 5.1.0, `pypdf` 6.21.4)
- **Samples**: `/workspace/venture-auto-top1/samples/`
- **Extractor**: `/workspace/venture-auto-top1/proto/extract.py`
- **Outputs**: `/workspace/venture-auto-top1/proto/out/`

## Results

| Sample | Expected rows | Extracted rows | Match | Extra checks |
|--------|---------------|----------------|-------|--------------|
| `bank_checking_sample.pdf` | 21 | 21 | **100% row count** | Opening → running balance chain → closing **OK** (`4521.37` → `9236.26`) |
| `paypal_like_activity_sample.pdf` | 20 | 20 | **100% row count** | Per-row `net = gross + fee` **OK**; period totals gross `431.24` / fee `-41.22` / net `390.02` **OK** |

CSV paths:
- `/workspace/venture-auto-top1/proto/out/bank_checking_sample.csv`
- `/workspace/venture-auto-top1/proto/out/paypal_like_activity_sample.csv`

Expected meta (from generator): `/workspace/venture-auto-top1/samples/expected_meta.json`

## What “100%” means here

Accuracy is **only** for the two text-PDF layouts we generated (Courier-aligned tables + known headers). This is a feasibility check for MVP parsers, **not** a claim about Chase/BofA/live PayPal PDFs or scanned OCR.

## Known failure modes (expected)

1. **Unsupported layout** — any PDF without Northbridge / SAMPLE activity markers → hard error (by design).
2. **Scanned / image-only PDF** — `pypdf` returns little/no text → 0 rows (no OCR in MVP).
3. **Multi-column or wrapped description lines** — regex assumes one transaction per line; wrapped merchant names would drop or split rows.
4. **Locale formats** — European `dd.mm.yyyy` / comma decimals not supported.
5. **Header/footer noise on real banks** — page numbers, legal blurbs, or multi-account sections can inject false matches or break spacing.
6. **Amount without leading `+`/`-` on bank layout** — bank regex requires signed amount token as generated.
7. **PayPal STL / CSV** — out of scope; this targets PDF activity statements only.

## How to re-run

```bash
cd /workspace/venture-auto-top1
.venv/bin/python proto/generate_samples.py
.venv/bin/python proto/extract.py samples/bank_checking_sample.pdf -o proto/out/bank_checking_sample.csv --check
.venv/bin/python proto/extract.py samples/paypal_like_activity_sample.pdf -o proto/out/paypal_like_activity_sample.csv --check
```
