# pdfminer x/y column clustering

**Date**: 2026-10-31 (Asia/Shanghai)  
**Module**: `proto/extract_xy.py` (wired from `proto/extract.py` for `chase_like` / `bofa_like` / `wells_like`)

## Why

Day-2b Wells extraction used **Courier string character index** (`first_money_abs < 52`) to decide Credits vs Debits. That breaks as soon as the bank uses a proportional font or different column widths. Real e-statements need **glyph x-coordinates**.

## Pipeline

1. **`iter_text_lines(pdf)`** — `pdfminer.high_level.extract_pages` → walk `LTTextLine` / `LTChar`; keep each glyph’s `(x0, x1, y0, y1)`.
2. **`money_tokens(line)`** — regex `[+-]?\$?[0-9,]+\.\d{2}` on the glyph string; each match gets `xc = (x0+x1)/2` from its characters.
3. **`cluster_1d(xs, gap≈18pt)`** — sort x-centers; start a new cluster when consecutive gap `> gap`; centroid = mean of the run.
4. **Assign** each money token to the nearest named column centroid.

## Layout-specific

| Layout | Columns | How centroids are chosen |
|--------|---------|---------------------------|
| **Wells-like** | Credits · Debits · Bal | Prefer header anchors (`Credits`/`Debits`/`Bal` word x-centers). Else cluster txn money x’s → leftmost=credit, middle=debit, rightmost=balance. Amount = credit − debit. |
| **Chase-like** | Amount · Balance | Cluster txn money x’s into 2; left=amount, right=balance. Sign from `-` glyph left of the amount token. |
| **BofA-like** | Amount (unsigned) | Section headers still decide credit vs debit sign. Amount = money token nearest (or rightmost near) the clustered amount centroid. |

Legacy **Northbridge** / **PayPal-like** stay on plain `pypdf` text + regex (single signed columns; no credit/debit dual columns).

## What this does *not* do

- No OCR (image-only PDFs still fail closed).
- No learning / ML — fixed gap threshold + nearest centroid.
- Does not invent columns that never appear (a statement with only one money column yields one cluster).

## Re-check

```bash
cd /workspace/venture-auto-top1
.venv/bin/python proto/run_accuracy_realish.py
```
