# Parser accuracy — realish US bank layouts (Day-2b)

- **Date**: 2026-10-31 (Asia/Shanghai)
- **Runtime**: `/workspace/venture-auto-top1/.venv` (`reportlab` 5.1.0, `pypdf` 6.21.4, `pdfminer.six`)
- **Research notes**: `/workspace/venture-auto-top1/proto/layouts-research.md`
- **Generator**: `/workspace/venture-auto-top1/proto/generate_realish.py`
- **Extractor**: `/workspace/venture-auto-top1/proto/extract.py` + `extract_xy.py` (Chase/BofA/Wells via pdfminer x/y clustering; legacy Northbridge/PayPal text paths kept)
- **Suite**: `/workspace/venture-auto-top1/proto/run_accuracy_realish.py`
- **Outputs**: `/workspace/venture-auto-top1/proto/out/realish/`
- **PII**: none — all holders/emails/accounts fictional; bank names are DEMO brands mimicking **public** layout descriptions (not affiliated with Chase / BofA / Wells Fargo)

## Samples

| File | Layout family modeled | Columns (simplified) |
|------|----------------------|----------------------|
| `samples/realish/chase_like.pdf` | Chase personal checking | `MM/DD` · Description · signed Amount · Balance |
| `samples/realish/bofa_like.pdf` | BofA sectioned checking | Sections: Deposits / Withdrawals · `MM/DD/YY` · unsigned Amount; separate Daily balance summary |
| `samples/realish/wells_like.pdf` | Wells Fargo dual-column | `M/D` · Check# · Description · Credits · Debits · Ending daily Bal |
| Sidecars | Ground truth | `samples/realish/{chase,bofa,wells}_like.csv` + `expected_meta.json` |

Shared ledger: opening **4521.37** → closing **9236.26**, **21** transactions (same economics as Day-2 Northbridge sample).

## Results

| Sample | Detected layout | Rows | vs truth CSV | Balance / totals check |
|--------|-----------------|------|--------------|------------------------|
| `bank_checking_sample.pdf` (legacy) | `bank_checking` | 21/21 | n/a (meta only) | Opening → chain → closing **OK** |
| `paypal_like_activity_sample.pdf` (legacy) | `paypal_like` | 20/20 | n/a | Per-row net + period totals **OK** |
| `chase_like.pdf` | `chase_like` | **21/21** | date/amount/balance **match** | Chain + closing **OK** (`9236.26`) |
| `bofa_like.pdf` | `bofa_like` | **21/21** | date/amount/balance **match** (balances reconstructed from opening + section signs; daily summary cross-check) | Chain + closing **OK** |
| `wells_like.pdf` | `wells_like` | **21/21** | date/amount/balance **match** (desc may truncate to PDF width) | Chain + closing **OK** |

JSON machine report: `proto/out/realish/accuracy_report.json`

## Day-2c — pdfminer x/y clustering (before → after)

**Change**: Wells/BofA/Chase column assignment no longer uses Courier string positions (`first_money_abs < 52`). Columns come from pdfminer glyph `x` clustering / header anchors (`proto/extract_xy.py`, notes in `proto/xy-clustering.md`).

| Sample | Before (Day-2b string pos) | After (Day-2c xy cluster) | Regressions |
|--------|----------------------------|---------------------------|-------------|
| `bank_checking_sample.pdf` | 21/21 + balance OK | **21/21 + balance OK** | none |
| `paypal_like_activity_sample.pdf` | 20/20 + totals OK | **20/20 + totals OK** | none |
| `chase_like.pdf` | 21/21 + truth + balance OK | **21/21 + truth + balance OK** (`column_mode=pdfminer_xy_cluster`) | none |
| `bofa_like.pdf` | 21/21 + truth + balance OK | **21/21 + truth + balance OK** | none |
| `wells_like.pdf` | 21/21 + truth + balance OK (Courier index heuristic) | **21/21 + truth + balance OK** (header anchors Credits/Debits/Bal) | none |

**Ready for user-donated redacted PDFs?** **Yes, technically** — text-layer digital statements only; strip names/account digits before sharing. Scanned/image PDFs still out of scope. Do **not** collect real PII in-agent; wait for user to place redacted fixtures under e.g. `samples/redacted/`.


## What still fails / known failure modes

1. **Scanned / image-only PDFs** — `pypdf` returns empty text → hard error: *"No extractable text… OCR not enabled."* Needs OCR (Tesseract or cloud). **Out of MVP.**
2. **Multi-line wrapped descriptions** — one-txn-per-line assumption; continuation lines without dates become orphans or are dropped.
3. **Chase business sectioned layout** — deposits vs withdrawals sections without per-row balance (different from personal `chase_like`). Not in this suite.
4. **Same-day multi-txn on BofA** — section extraction then chronological sort; if credit+debit same day, order within the day may not match bank print order (balance still reconciles if both included).
5. **Wells ending-daily-balance only** — missing mid-day balances filled from running chain. Column sign now uses **pdfminer x/y clustering** (header anchors or money-centroid clusters), not Courier string index. Still sensitive to unusual multi-amount rows / overlapping columns.
6. **Year-boundary statements** (Dec–Jan) — year recovery from period header is naive (single year).
7. **Locale** — European dates / comma decimals unsupported.
8. **Password-protected e-statements** — not handled.
9. **Real bank PDFs** — still untested; these are synthetic-but-realistic text layouts only.

## Text-layer vs OCR — MVP recommendation

| Input | MVP? | Why |
|-------|------|-----|
| Digital bank PDF with selectable text | **Yes** | Regex/heuristics + balance reconciliation; low infra cost |
| PayPal/platform activity PDF (text) | **Yes** (existing) | Same pipeline |
| Scanned photo / image-only PDF | **No (v1)** | OCR cost, PII retention risk, higher error rate → soft-fail with “export text PDF from your bank” message |
| Bank CSV/QFX download | Later upsell | Many users already have CSV; different product surface |

**Ship text-layer only for the 7-day validation.** Add OCR only after paid demand and a privacy story (delete-after-parse).

## How to re-run

```bash
cd /workspace/venture-auto-top1
.venv/bin/python proto/generate_realish.py
.venv/bin/python proto/run_accuracy_realish.py
# or single file:
.venv/bin/python proto/extract.py samples/realish/chase_like.pdf -o proto/out/realish/chase_like.csv --check
```

## Recommended next technical step

1. ~~pdfminer x/y clustering~~ **Done (Day-2c)** — see `proto/xy-clustering.md`.
2. Accept **user-donated redacted** text-layer PDFs into `samples/redacted/` (strip names/account digits) — do **not** download real customer statements in-agent.
3. Soft-fail UX copy for image-only uploads; defer OCR.
4. Then public fake-door landing (still deferred per user).
