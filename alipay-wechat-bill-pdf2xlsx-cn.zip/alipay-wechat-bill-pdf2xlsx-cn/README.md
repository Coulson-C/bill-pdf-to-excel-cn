# 支付宝 / 微信账单 PDF → Excel（本地包 · 旗舰）

把支付宝「交易流水证明」、微信「交易明细证明」等**可选中文字**的账单 PDF，在自己电脑整理成 Excel / CSV。  
也兼容官方「个人对账」导出的 **CSV**（字段对齐时）。  
**不上传。不做扫描 OCR。不是银行流水包。不是电子发票包。**

版本：burn-night-2026-10-31 · 旗舰 SKU（相对旧 `bill-pdf-to-excel-cn`：真正面向支付宝/微信，批量 + 失败说明 + 中文说明齐全）

---

## 你能得到什么

| 内容 | 说明 |
|------|------|
| `extract_bill_cn.py` | 主程序：批量抽取 → Excel |
| `requirements.txt` | Python 依赖 |
| `一键演示.sh` / `一键演示.bat` | 安装依赖并跑通样例 |
| `samples/` | 虚构支付宝/微信证明 PDF + 官方风格 CSV + 扫描件对照 |
| `expected/` | 样例期望输出（对照用） |
| `scripts/generate_samples.py` | 重新生成演示样例（可选） |
| `docs/支持版式与字段.md` | 版式边界 |

---

## 环境

- Windows 10/11、macOS 或 Linux  
- Python **3.10+**  
- PDF 为**文本层**（阅读器里能选中、复制文字）

---

## 安装与演示（推荐先跑样例）

```bash
python -m venv .venv

# Windows:
.venv\Scripts\activate

# macOS / Linux:
source .venv/bin/activate

pip install -r requirements.txt
python extract_bill_cn.py samples/synth-alipay-proof-like.pdf samples/synth-wechat-proof-like.pdf -o out/账单明细.xlsx
```

或执行：`一键演示.bat` / `bash 一键演示.sh`。

用 Excel / WPS 打开 `out/账单明细.xlsx`，应约 **13 行**明细（支付宝 7 + 微信 6）+ 收入/支出合计。

---

## 转换你自己的账单

1. 打开 PDF，确认**能选中文字**。扫描件/拍照件本包不支持。  
2. 建议复制并打码姓名、完整账号、证件号后再试。  
3. 运行：

```bash
python extract_bill_cn.py 你的账单.pdf -o out/账单明细.xlsx
# 或整个文件夹（默认跳过文件名含 scan 的样例）：
python extract_bill_cn.py ./账单目录 -o out/账单明细.xlsx --csv out/账单明细.csv
```

4. 若已有官方「个人对账」**CSV**，也可直接丢给本工具统一成同一套表头。

**更省事的路径**：支付宝 / 微信 App 里「用于个人对账」往往直接给 Excel/CSV —— 能官方导出就优先官方；本工具主要补「只有证明 PDF、且文字可选中」的缺口。

---

## 输出说明

- Sheet「账单明细」：统一字段 + 合计行（收入 / 支出 / 净额）  
- Sheet「失败说明」：无文本层、无法识别版式、0 行等，**不静默丢弃**  
- Sheet「批次说明」：本批统计与逐文件备注  

字段：交易时间、交易分类、交易对方、商品说明、收/支、金额、收付款方式、交易状态、交易订单号、商家订单号、备注、版式、来源文件、状态。

---

## 首发支持版式

| 版式代码 | 含义 | 样例 |
|----------|------|------|
| `alipay_proof_like` | 支付宝交易流水证明风格（一行一笔） | `synth-alipay-proof-like.pdf` |
| `wechat_proof_like` | 微信交易明细证明风格（一行一笔） | `synth-wechat-proof-like.pdf` |
| `alipay_csv` / `wechat_csv` | 官方个人对账 CSV 字段 | `synth-*-official-like.csv` |

真实盖章证明 PDF 若是复杂多列表格、CID 乱码、跨行商品名，可能与合成样例不同 → **漏行/错列请人工核对**。反馈时描述表头文字，**勿发未打码原件**。

---

## 能力边界（请务必阅读）

**做得到（本包实测）**

- 合成支付宝 / 微信证明风格文本层 PDF → Excel  
- 官方风格 CSV → 同一 Excel 表头  
- 批量文件夹；失败写入「失败说明」  
- 订单号按文本写入，减轻科学计数法  

**明确不做 / 易失败**

- 扫描件、纯图片 PDF（无 OCR）  
- 加密 PDF  
- 银行流水、电子发票（请购对应商品）  
- 保证「每一次官方改版证明 PDF 都 100%」  
- 代记账、报税、刷单相关  

---

## 常见问题

**App 已经能导出 Excel，还要买这个吗？**  
多数情况不必。适合：手里只有证明 PDF、或要把多份 PDF/CSV 收成一张表。

**要会写代码吗？** 不用，按本文命令即可。  

**必须联网吗？** 安装依赖时需要；解析本地完成。  

**可以退吗？** 以爱发电商品页为准；链接失效可私信订单号补发。

---

## 免责声明

1. 辅助整理工具；结果须人工核对。  
2. 不保证所有真实版式一次完美。  
3. 隐私与数据合法来源由使用者负责；勿把未打码账单发给陌生人（含卖家）。  
4. 支付宝 / 微信等商标归各权利人；提及仅为场景说明。本包非官方产品。

---

## 同系列

- 电子发票 PDF/OFD/XML → Excel  
- 国内银行流水（工行/建行/招行文本层）→ Excel  
