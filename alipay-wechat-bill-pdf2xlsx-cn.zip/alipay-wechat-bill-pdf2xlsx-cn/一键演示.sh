#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 -m venv .venv
# shellcheck disable=SC1091
source .venv/bin/activate
pip install -r requirements.txt
python extract_bill_cn.py samples/synth-alipay-proof-like.pdf samples/synth-wechat-proof-like.pdf -o out/账单明细.xlsx --csv out/账单明细.csv
echo "完成：out/账单明细.xlsx（约 13 行明细）"
