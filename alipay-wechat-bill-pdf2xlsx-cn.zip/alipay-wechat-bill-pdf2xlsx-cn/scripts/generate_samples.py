#!/usr/bin/env python3
"""生成支付宝/微信「证明材料」风格合成 PDF + CSV 样例（虚构数据）。"""
from __future__ import annotations

import csv
from pathlib import Path

from reportlab.lib.pagesizes import A4
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.pdfgen import canvas

ROOT = Path(__file__).resolve().parents[1]
SAMPLES = ROOT / "samples"
FONT = "STSong-Light"
pdfmetrics.registerFont(UnicodeCIDFont(FONT))


def draw_lines(path: Path, title: str, meta: list[str], header: str, rows: list[str]) -> None:
    c = canvas.Canvas(str(path), pagesize=A4)
    w, h = A4
    y = h - 40
    c.setFont(FONT, 13)
    c.drawString(40, y, title)
    y -= 18
    c.setFont(FONT, 9)
    c.drawString(40, y, "SYNTHETIC / DESENSITIZED SAMPLE — NOT A REAL STATEMENT")
    y -= 14
    for m in meta:
        c.drawString(40, y, m)
        y -= 13
    y -= 6
    c.setFont(FONT, 8)
    c.drawString(40, y, header)
    y -= 12
    for r in rows:
        if y < 40:
            c.showPage()
            c.setFont(FONT, 8)
            y = h - 40
        c.drawString(36, y, r)
        y -= 11
    c.save()
    print("wrote", path)


def write_scan_control() -> None:
    from io import BytesIO

    from PIL import Image, ImageDraw

    img = Image.new("RGB", (700, 220), "white")
    d = ImageDraw.Draw(img)
    d.text((30, 90), "SCAN IMAGE ONLY - NO TEXT LAYER", fill="black")
    buf = BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    c = canvas.Canvas(str(SAMPLES / "synth-scan-no-textlayer.pdf"), pagesize=A4)
    c.drawImage(ImageReader(buf), 40, 500, width=520, height=160)
    c.save()
    print("wrote scan control")


def write_alipay_csv() -> None:
    path = SAMPLES / "synth-alipay-official-like.csv"
    # mimic official: preamble + header + rows
    with path.open("w", encoding="gbk", newline="") as f:
        f.write("支付宝交易记录明细查询\n")
        f.write("账号:[demo***@example.com]\n")
        f.write("起始时间:[2025-01-01 00:00:00]    终止时间:[2025-01-31 23:59:59]\n")
        f.write("----------------------------------------\n")
        w = csv.writer(f)
        w.writerow(
            [
                "交易时间",
                "交易分类",
                "交易对方",
                "对方账号",
                "商品说明",
                "收/支",
                "金额",
                "收/付款方式",
                "交易状态",
                "交易订单号",
                "商家订单号",
                "备注",
            ]
        )
        w.writerow(
            [
                "2025-01-03 12:34:56",
                "餐饮美食",
                "某某奶茶店",
                "demo***",
                "招牌奶茶",
                "支出",
                "18.00",
                "余额宝",
                "交易成功",
                "2025010322001400123456789",
                "M20250103001",
                "",
            ]
        )
        w.writerow(
            [
                "2025-01-05 09:10:00",
                "转账红包",
                "张*",
                "",
                "转账",
                "收入",
                "200.00",
                "",
                "交易成功",
                "2025010522001400987654321",
                "",
                "午饭分摊",
            ]
        )
        f.write("----------------------------------------\n")
    print("wrote", path)


def write_wechat_csv() -> None:
    path = SAMPLES / "synth-wechat-official-like.csv"
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(
            [
                "交易时间",
                "交易类型",
                "交易对方",
                "商品",
                "收/支",
                "金额(元)",
                "支付方式",
                "当前状态",
                "交易单号",
                "商户单号",
                "备注",
            ]
        )
        w.writerow(
            [
                "2025-01-04 18:22:11",
                "商户消费",
                "某连锁超市",
                "日用品",
                "支出",
                "56.30",
                "零钱",
                "支付成功",
                "4200001234202501041234567890",
                "WX20250104001",
                "",
            ]
        )
        w.writerow(
            [
                "2025-01-08 21:00:02",
                "转账",
                "李*",
                "/",
                "收入",
                "88.00",
                "/",
                "已收钱",
                "1000050001202501080987654321",
                "",
                "电影票",
            ]
        )
    print("wrote", path)


def main() -> None:
    SAMPLES.mkdir(parents=True, exist_ok=True)
    # Alipay proof-like PDF (one txn per line — parseable text layer)
    draw_lines(
        SAMPLES / "synth-alipay-proof-like.pdf",
        "支付宝（合成样例）交易流水证明",
        [
            "证明编号：DEMO-ALIPAY-202501  申请人：测**  证件号：**************1234",
            "查询区间：2025-01-01 至 2025-01-31  用途：个人对账演示（虚构）",
        ],
        "交易时间 分类 对方 商品 收/支 金额 方式 状态 订单号 商家订单号 备注",
        [
            "2025-01-03 12:34:56 餐饮美食 某某奶茶店 招牌奶茶 支出 18.00 余额宝 交易成功 2025010322001400123456789 M20250103001",
            "2025-01-05 09:10:00 转账红包 张* 转账 收入 200.00 余额 交易成功 2025010522001400987654321 - 午饭分摊",
            "2025-01-09 19:45:33 日用百货 某超市旗舰店 纸巾抽纸 支出 29.90 花呗 交易成功 2025010922001400556677889 M20250109088",
            "2025-01-12 08:01:00 交通出行 某出行平台 快车 支出 23.50 余额宝 交易成功 2025011222001400112233445 M20250112011",
            "2025-01-15 14:20:18 退款 某电商 退款-耳机 收入 199.00 余额 退款成功 2025011522001400998877665 M20250115002",
            "2025-01-20 11:11:11 充值缴费 某通信 话费充值 支出 50.00 余额宝 交易成功 2025012022001400332211009 M20250120077",
            "2025-01-28 22:03:44 投资理财 余额宝 收益发放 收入 3.26 余额宝 交易成功 2025012822001400001112223 -",
        ],
    )
    draw_lines(
        SAMPLES / "synth-wechat-proof-like.pdf",
        "微信支付（合成样例）交易明细证明",
        [
            "证明编号：DEMO-WECHAT-202501  姓名：测**  微信号：demo_user_***",
            "查询区间：2025-01-01 至 2025-01-31  本文件为虚构演示，非官方盖章件",
        ],
        "交易时间 类型 对方 商品 收/支 金额 方式 状态 交易单号 商户单号 备注",
        [
            "2025-01-04 18:22:11 商户消费 某连锁超市 日用品 支出 56.30 零钱 支付成功 4200001234202501041234567890 WX20250104001",
            "2025-01-08 21:00:02 转账 李* / 收入 88.00 / 已转账 1000050001202501080987654321 - 电影票",
            "2025-01-10 12:15:40 扫二维码付款 某面馆 午餐 支出 32.00 银行卡 支付成功 4200001234202501102233445566 WX20250110015",
            "2025-01-16 09:30:00 微信红包 王* 红包 收入 5.20 / 已收钱 1000030001202501161122334455 -",
            "2025-01-22 20:45:18 商户消费 某咖啡 美式咖啡 支出 28.00 零钱 支付成功 4200001234202501223344556677 WX20250122088",
            "2025-01-25 16:02:03 退款 某电商平台 退款 收入 128.00 零钱 已退款 4200001234202501254455667788 WX20250125001",
        ],
    )
    write_scan_control()
    write_alipay_csv()
    write_wechat_csv()


if __name__ == "__main__":
    main()
