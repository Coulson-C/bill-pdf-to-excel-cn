#!/usr/bin/env python3
"""支付宝 / 微信账单（文本层 PDF）→ Excel/CSV 本地工具。

首发版式（包内合成样例可跑通）：
  - alipay_proof_like  支付宝「交易流水证明」风格明细 PDF
  - wechat_proof_like  微信支付「交易明细证明」风格明细 PDF

可选：官方「个人对账」导出的 CSV（字段与官方一致时）→ 同一套 Excel。

诚实边界：
  - 不做扫描件 OCR；不做银行流水；不做电子发票
  - 真实证明 PDF 版式可能与合成样例不同 → 可能漏行/错列，须人工核对
  - 若 App 已能导出 Excel/CSV，优先用官方文件；本工具面向「只有 PDF 且可选中文字」
"""
from __future__ import annotations

import argparse
import csv
import re
import sys
from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Font, Alignment
from pypdf import PdfReader

FIELDNAMES = [
    "交易时间",
    "交易分类",
    "交易对方",
    "商品说明",
    "收/支",
    "金额",
    "收付款方式",
    "交易状态",
    "交易订单号",
    "商家订单号",
    "备注",
    "版式",
    "来源文件",
    "状态",
]

FAIL_HEADERS = ["来源文件", "状态", "说明"]


@dataclass
class FileResult:
    layout: str
    rows: list[dict]
    status: str = "OK"  # OK | PARTIAL | FAIL
    note: str = ""
    source: str = ""


def pdf_text(path: Path) -> str:
    reader = PdfReader(str(path))
    return "\n".join((page.extract_text() or "") for page in reader.pages)


def _dec(s: str) -> str:
    s = (s or "").strip().replace(",", "").replace("¥", "").replace("元", "")
    if not s or s == "-":
        return ""
    try:
        return f"{Decimal(s):.2f}"
    except InvalidOperation:
        return s


def _blank_row(**kwargs) -> dict:
    r = {h: "" for h in FIELDNAMES}
    r.update(kwargs)
    return r


def detect_layout(text: str, path: Path | None = None) -> str:
    name = (path.name if path else "").lower()
    if "支付宝" in text or "alipay" in text.lower() or "交易流水证明" in text:
        if "微信" in text and "支付宝" not in text[:200]:
            pass
        else:
            return "alipay_proof_like"
    if (
        "微信支付" in text
        or "微信交易明细" in text
        or "交易明细证明" in text
        or "wechat" in text.lower()
    ):
        return "wechat_proof_like"
    # filename hints for synth samples
    if "alipay" in name:
        return "alipay_proof_like"
    if "wechat" in name or "weixin" in name:
        return "wechat_proof_like"
    # header-line heuristics
    if "交易分类" in text and "收/支" in text and "交易订单号" in text:
        return "alipay_proof_like"
    if "交易类型" in text and ("交易单号" in text or "商户单号" in text):
        return "wechat_proof_like"
    raise ValueError(
        "未能识别支付宝/微信账单版式。"
        "当前支持：支付宝交易流水证明风格、微信交易明细证明风格（文本层 PDF）。"
        "扫描件请换官方导出；银行流水/电子发票请购对应商品。"
    )


# --- Alipay proof-like: one transaction per line ------------------------
# 交易时间 分类 对方 商品 收/支 金额 方式 状态 订单号 [商家订单号] [备注]

ALIPAY_LINE = re.compile(
    r"^(?P<dt>\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})\s+"
    r"(?P<cat>\S+)\s+"
    r"(?P<cp>\S+)\s+"
    r"(?P<goods>.+?)\s+"
    r"(?P<io>收入|支出|不计收支)\s+"
    r"(?P<amt>\d+\.\d{2})\s+"
    r"(?P<pay>\S+)\s+"
    r"(?P<st>\S+)\s+"
    r"(?P<oid>[0-9A-Za-z]+)"
    r"(?:\s+(?P<mid>[0-9A-Za-z_-]+))?"
    r"(?:\s+(?P<note>.+))?\s*$"
)

# Compact variant without 收付款方式 column
ALIPAY_LINE_COMPACT = re.compile(
    r"^(?P<dt>\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})\s+"
    r"(?P<cat>\S+)\s+"
    r"(?P<cp>\S+)\s+"
    r"(?P<goods>.+?)\s+"
    r"(?P<io>收入|支出|不计收支)\s+"
    r"(?P<amt>\d+\.\d{2})\s+"
    r"(?P<st>交易成功|支付成功|退款成功|已关闭|成功)\s+"
    r"(?P<oid>[0-9A-Za-z]+)"
    r"(?:\s+(?P<note>.+))?\s*$"
)


def parse_alipay(text: str, source: str) -> FileResult:
    rows: list[dict] = []
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("SYNTHETIC") or "表头" in line:
            continue
        m = ALIPAY_LINE.match(line) or ALIPAY_LINE_COMPACT.match(line)
        if not m:
            continue
        g = m.groupdict()
        rows.append(
            _blank_row(
                **{
                    "交易时间": g["dt"],
                    "交易分类": g.get("cat", ""),
                    "交易对方": g.get("cp", ""),
                    "商品说明": g.get("goods", "").strip(),
                    "收/支": g.get("io", ""),
                    "金额": _dec(g.get("amt", "")),
                    "收付款方式": g.get("pay", "") or "",
                    "交易状态": g.get("st", ""),
                    "交易订单号": g.get("oid", ""),
                    "商家订单号": g.get("mid", "") or "",
                    "备注": (g.get("note") or "").strip(),
                    "版式": "alipay_proof_like",
                    "来源文件": source,
                    "状态": "OK",
                }
            )
        )
    if rows:
        return FileResult("alipay_proof_like", rows, "OK", "", source)
    return FileResult(
        "alipay_proof_like",
        [],
        "FAIL",
        "识别为支付宝风格，但未解析到交易行。可能是版式与合成样例差异较大、或文字被拆成多行。",
        source,
    )


# --- WeChat proof-like -------------------------------------------------

WECHAT_LINE = re.compile(
    r"^(?P<dt>\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})\s+"
    r"(?P<typ>\S+)\s+"
    r"(?P<cp>\S+)\s+"
    r"(?P<goods>.+?)\s+"
    r"(?P<io>收入|支出|/)\s+"
    r"(?P<amt>\d+\.\d{2})\s+"
    r"(?P<pay>\S+)\s+"
    r"(?P<st>\S+)\s+"
    r"(?P<oid>[0-9A-Za-z]+)"
    r"(?:\s+(?P<mid>[0-9A-Za-z_-]+))?"
    r"(?:\s+(?P<note>.+))?\s*$"
)

WECHAT_LINE_COMPACT = re.compile(
    r"^(?P<dt>\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})\s+"
    r"(?P<typ>\S+)\s+"
    r"(?P<cp>\S+)\s+"
    r"(?P<goods>.+?)\s+"
    r"(?P<io>收入|支出|/)\s+"
    r"(?P<amt>\d+\.\d{2})\s+"
    r"(?P<st>支付成功|已转账|朋友已收钱|已退款|成功)\s+"
    r"(?P<oid>[0-9A-Za-z]+)"
    r"(?:\s+(?P<note>.+))?\s*$"
)


def parse_wechat(text: str, source: str) -> FileResult:
    rows: list[dict] = []
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("SYNTHETIC"):
            continue
        m = WECHAT_LINE.match(line) or WECHAT_LINE_COMPACT.match(line)
        if not m:
            continue
        g = m.groupdict()
        rows.append(
            _blank_row(
                **{
                    "交易时间": g["dt"],
                    "交易分类": g.get("typ", ""),  # 微信侧多为「交易类型」
                    "交易对方": g.get("cp", ""),
                    "商品说明": g.get("goods", "").strip(),
                    "收/支": g.get("io", ""),
                    "金额": _dec(g.get("amt", "")),
                    "收付款方式": g.get("pay", "") or "",
                    "交易状态": g.get("st", ""),
                    "交易订单号": g.get("oid", ""),
                    "商家订单号": g.get("mid", "") or "",
                    "备注": (g.get("note") or "").strip(),
                    "版式": "wechat_proof_like",
                    "来源文件": source,
                    "状态": "OK",
                }
            )
        )
    if rows:
        return FileResult("wechat_proof_like", rows, "OK", "", source)
    return FileResult(
        "wechat_proof_like",
        [],
        "FAIL",
        "识别为微信风格，但未解析到交易行。真实盖章证明 PDF 若为多列表格/复杂排版，可能需人工核对或换「个人对账」Excel。",
        source,
    )


PARSERS = {
    "alipay_proof_like": parse_alipay,
    "wechat_proof_like": parse_wechat,
}


def extract_pdf(path: Path) -> FileResult:
    text = pdf_text(path)
    if not text.strip():
        return FileResult(
            "",
            [],
            "FAIL",
            "无文本层（可能是扫描件/纯图 PDF）。本包不做 OCR。"
            "请改用官方「个人对账」Excel，或重新导出可选中文字的证明 PDF。",
            path.name,
        )
    # Reject obvious bank / invoice to reduce cross-SKU misuse
    if any(
        k in text
        for k in ("中国工商银行", "中国建设银行", "招商银行", "增值税", "发票号码", "价税合计")
    ) and not any(k in text for k in ("支付宝", "微信支付", "交易流水证明", "交易明细证明")):
        return FileResult(
            "",
            [],
            "FAIL",
            "内容更像银行流水或电子发票，不是支付宝/微信账单。请购对应商品。",
            path.name,
        )
    try:
        layout = detect_layout(text, path)
    except ValueError as e:
        return FileResult("", [], "FAIL", str(e), path.name)
    return PARSERS[layout](text, path.name)


# --- Official CSV (Alipay / WeChat personal reconciliation) -------------

ALIPAY_CSV_HEADERS = [
    "交易时间",
    "交易分类",
    "交易对方",
    "对方账号",
    "商品说明",
    "收/支",
    "金额",
    "收/付款方式",
    "交易状态",
    "交易订单号",
    "商家订单号",
    "备注",
]

WECHAT_CSV_HEADERS = [
    "交易时间",
    "交易类型",
    "交易对方",
    "商品",
    "收/支",
    "金额(元)",
    "支付方式",
    "当前状态",
    "交易单号",
    "商户单号",
    "备注",
]


def _read_csv_rows(path: Path) -> tuple[list[str], list[list[str]]]:
    raw = path.read_bytes()
    text = None
    for enc in ("utf-8-sig", "utf-8", "gbk", "gb18030"):
        try:
            text = raw.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    if text is None:
        raise ValueError("无法解码 CSV（尝试了 utf-8 / gbk）")
    # Alipay CSV often has ~20+ preamble lines before header
    lines = text.splitlines()
    header_idx = None
    for i, line in enumerate(lines):
        if "交易时间" in line and ("交易分类" in line or "交易类型" in line):
            header_idx = i
            break
    if header_idx is None:
        raise ValueError("CSV 中未找到含「交易时间」的表头行")
    # Use csv module on the slice
    import io

    chunk = "\n".join(lines[header_idx:])
    reader = csv.reader(io.StringIO(chunk))
    rows = list(reader)
    if not rows:
        raise ValueError("CSV 表头后无数据")
    header = [c.strip().lstrip("\ufeff").lstrip("`") for c in rows[0]]
    data = []
    for r in rows[1:]:
        if not any(c.strip() for c in r):
            continue
        # skip alipay footer summaries
        joined = "".join(r)
        if joined.startswith("----") or "交易合计" in joined or "导出时间" in joined:
            continue
        data.append([c.strip().lstrip("`") for c in r])
    return header, data


def _map_by_header(header: list[str], row: list[str], mapping: dict[str, str]) -> dict:
    idx = {h: i for i, h in enumerate(header)}
    out = _blank_row()
    for src, dst in mapping.items():
        if src in idx and idx[src] < len(row):
            out[dst] = row[idx[src]]
    return out


def extract_csv(path: Path) -> FileResult:
    try:
        header, data = _read_csv_rows(path)
    except Exception as e:
        return FileResult("", [], "FAIL", f"CSV 读取失败: {e}", path.name)

    hset = set(header)
    rows: list[dict] = []
    if "交易分类" in hset and "交易订单号" in hset:
        layout = "alipay_csv"
        mapping = {
            "交易时间": "交易时间",
            "交易分类": "交易分类",
            "交易对方": "交易对方",
            "商品说明": "商品说明",
            "收/支": "收/支",
            "金额": "金额",
            "收/付款方式": "收付款方式",
            "交易状态": "交易状态",
            "交易订单号": "交易订单号",
            "商家订单号": "商家订单号",
            "备注": "备注",
        }
    elif "交易类型" in hset and ("交易单号" in hset or "金额(元)" in hset):
        layout = "wechat_csv"
        mapping = {
            "交易时间": "交易时间",
            "交易类型": "交易分类",
            "交易对方": "交易对方",
            "商品": "商品说明",
            "收/支": "收/支",
            "金额(元)": "金额",
            "支付方式": "收付款方式",
            "当前状态": "交易状态",
            "交易单号": "交易订单号",
            "商户单号": "商家订单号",
            "备注": "备注",
        }
    else:
        return FileResult(
            "",
            [],
            "FAIL",
            f"CSV 表头无法识别为支付宝/微信个人账单。表头={header[:8]}…",
            path.name,
        )

    for r in data:
        d = _map_by_header(header, r, mapping)
        d["金额"] = _dec(d.get("金额", ""))
        d["版式"] = layout
        d["来源文件"] = path.name
        d["状态"] = "OK"
        # skip empty time
        if not d.get("交易时间"):
            continue
        rows.append(d)

    if not rows:
        return FileResult(layout, [], "FAIL", "CSV 无有效交易行", path.name)
    return FileResult(layout, rows, "OK", "", path.name)


def extract_one(path: Path) -> FileResult:
    suf = path.suffix.lower()
    if suf == ".pdf":
        return extract_pdf(path)
    if suf == ".csv":
        return extract_csv(path)
    return FileResult("", [], "FAIL", f"不支持的扩展名: {suf}（支持 .pdf / .csv）", path.name)


def collect_files(inputs: list[Path], include_scan: bool = False) -> list[Path]:
    files: list[Path] = []
    for p in inputs:
        if p.is_dir():
            for ext in ("*.pdf", "*.PDF", "*.csv", "*.CSV"):
                files.extend(sorted(p.glob(ext)))
        elif p.is_file():
            files.append(p)
    if not include_scan:
        filtered = [f for f in files if "scan" not in f.name.lower()]
        if filtered:
            files = filtered
    # de-dupe preserve order
    seen = set()
    out = []
    for f in files:
        key = str(f.resolve()) if f.exists() else str(f)
        if key not in seen:
            seen.add(key)
            out.append(f)
    return out


def write_xlsx(
    txn_rows: list[dict],
    fails: list[dict],
    out: Path,
    summary_notes: list[str] | None = None,
) -> None:
    wb = Workbook()
    ws = wb.active
    ws.title = "账单明细"
    ws.append(FIELDNAMES)
    for c in ws[1]:
        c.font = Font(bold=True)

    income = Decimal("0")
    expense = Decimal("0")
    for r in txn_rows:
        vals = []
        for h in FIELDNAMES:
            v = r.get(h, "")
            if h in ("交易订单号", "商家订单号") and v is not None:
                v = str(v)
            vals.append(v)
        ws.append(vals)
        row_idx = ws.max_row
        for col_name in ("交易订单号", "商家订单号"):
            col = FIELDNAMES.index(col_name) + 1
            cell = ws.cell(row=row_idx, column=col)
            cell.number_format = "@"
            cell.alignment = Alignment(horizontal="left")
            if cell.value is not None:
                cell.value = str(cell.value)
        try:
            amt = Decimal(str(r.get("金额") or "0"))
        except InvalidOperation:
            amt = Decimal("0")
        io = str(r.get("收/支") or "")
        if "收入" in io:
            income += amt
        elif "支出" in io:
            expense += amt

    ws.append([])
    ws.append(
        [
            "合计",
            "",
            "",
            "",
            "",
            f"收入 {income:.2f} / 支出 {expense:.2f} / 净额 {income - expense:.2f}",
            "",
            "",
            f"{len(txn_rows)} 笔",
            "",
            "",
            "",
            "",
            "",
        ]
    )

    ws2 = wb.create_sheet("失败说明")
    ws2.append(FAIL_HEADERS)
    for c in ws2[1]:
        c.font = Font(bold=True)
    if fails:
        for f in fails:
            ws2.append([f.get("来源文件", ""), f.get("状态", ""), f.get("说明", "")])
    else:
        ws2.append(["（无）", "", "本批全部成功或无失败文件"])

    ws3 = wb.create_sheet("批次说明")
    ws3.append(["项", "内容"])
    ws3.append(["明细行数", len(txn_rows)])
    ws3.append(["失败文件数", len(fails)])
    ws3.append(["收入合计", f"{income:.2f}"])
    ws3.append(["支出合计", f"{expense:.2f}"])
    for n in summary_notes or []:
        ws3.append(["备注", n])

    out.parent.mkdir(parents=True, exist_ok=True)
    wb.save(out)


def write_csv(txn_rows: list[dict], out: Path) -> None:
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=FIELDNAMES, extrasaction="ignore")
        w.writeheader()
        for r in txn_rows:
            w.writerow({h: r.get(h, "") for h in FIELDNAMES})


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(
        description="支付宝/微信账单 PDF（文本层）或官方 CSV → Excel"
    )
    ap.add_argument("inputs", nargs="+", help="PDF/CSV 文件或文件夹")
    ap.add_argument("-o", "--output", default="out/账单明细.xlsx")
    ap.add_argument("--csv", dest="csv_out", default="", help="额外输出 CSV")
    ap.add_argument(
        "--include-scan",
        action="store_true",
        help="文件夹模式下也处理文件名含 scan 的样例（默认跳过）",
    )
    args = ap.parse_args(argv)

    files = collect_files([Path(p) for p in args.inputs], include_scan=args.include_scan)
    if not files:
        print("未找到 PDF/CSV。", file=sys.stderr)
        return 2

    all_rows: list[dict] = []
    fails: list[dict] = []
    notes: list[str] = []
    for f in files:
        res = extract_one(f)
        notes.append(f"{f.name}: layout={res.layout or '-'} status={res.status} rows={len(res.rows)}")
        if res.status == "FAIL" or (not res.rows and res.status != "OK"):
            fails.append(
                {
                    "来源文件": res.source or f.name,
                    "状态": res.status or "FAIL",
                    "说明": res.note or "未解析到交易行",
                }
            )
            print(f"FAIL {f.name}: {res.note}", file=sys.stderr)
            continue
        all_rows.extend(res.rows)
        if res.note:
            notes.append(res.note)
        print(f"OK {f.name}: {res.layout} → {len(res.rows)} 行")

    out = Path(args.output)
    write_xlsx(all_rows, fails, out, notes)
    if args.csv_out:
        write_csv(all_rows, Path(args.csv_out))
    print(f"写出 {len(all_rows)} 行明细 / {len(fails)} 个失败 → {out}")
    return 0 if all_rows and not fails else (0 if all_rows else 1)


if __name__ == "__main__":
    raise SystemExit(main())
