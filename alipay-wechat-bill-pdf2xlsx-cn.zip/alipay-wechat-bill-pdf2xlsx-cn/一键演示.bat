@echo off
cd /d "%~dp0"
python -m venv .venv
call .venv\Scripts\activate.bat
pip install -r requirements.txt
python extract_bill_cn.py samples\synth-alipay-proof-like.pdf samples\synth-wechat-proof-like.pdf -o out\账单明细.xlsx --csv out\账单明细.csv
echo 完成：out\账单明细.xlsx
pause
