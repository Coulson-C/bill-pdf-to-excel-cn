#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""电商主图本地批处理：压图 + 多平台尺寸 + 文字/Logo 水印 + 导出命名。图不上传。"""
from __future__ import annotations

import argparse
import json
import re
import sys
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Iterable

from PIL import Image, ImageDraw, ImageFont, ImageOps

SUPPORTED = {".jpg", ".jpeg", ".png", ".webp", ".bmp"}

DEFAULT_PRESETS: dict[str, dict] = {
    "taobao_800": {"label": "淘宝主图800方", "mode": "square", "size": 800},
    "taobao_1200": {"label": "淘宝主图1200方", "mode": "square", "size": 1200},
    "pdd_800": {"label": "拼多多主图800方", "mode": "square", "size": 800},
    "jd_800": {"label": "京东主图800方", "mode": "square", "size": 800},
    "douyin_800": {"label": "抖店主图800方", "mode": "square", "size": 800},
    "detail_750": {"label": "详情宽750", "mode": "width", "size": 750},
    "portrait_3x4_900": {"label": "竖图3:4宽900", "mode": "ratio", "w": 900, "h": 1200},
}

# 导出命名可用占位符：{stem} {preset} {label} {w} {h} {index} {date} {time} {quality}
DEFAULT_NAME_PATTERN = "{stem}_{preset}_{w}x{h}"

FONT_CANDIDATES = [
    "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
    "/usr/share/fonts/opentype/noto/NotoSerifCJK-Regular.ttc",
    "/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc",
    "/usr/share/fonts/truetype/wqy/wqy-microhei.ttc",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    "C:/Windows/Fonts/msyh.ttc",
    "C:/Windows/Fonts/simhei.ttf",
    "/System/Library/Fonts/PingFang.ttc",
    "/System/Library/Fonts/STHeiti Light.ttc",
]


@dataclass
class JobResult:
    src: Path
    outs: list[Path]
    note: str = ""


def load_presets(path: Path | None) -> dict:
    if path and path.is_file():
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            raise SystemExit("预设 JSON 必须是对象 {name: {...}}")
        return data
    return DEFAULT_PRESETS


def iter_images(folder: Path, recursive: bool) -> Iterable[Path]:
    files = folder.rglob("*") if recursive else folder.glob("*")
    for p in files:
        if p.is_file() and p.suffix.lower() in SUPPORTED:
            yield p


def pick_font(size: int) -> ImageFont.ImageFont:
    for fp in FONT_CANDIDATES:
        try:
            if Path(fp).is_file() or fp.endswith((".ttf", ".ttc", ".otf")):
                return ImageFont.truetype(fp, size)
        except OSError:
            continue
    return ImageFont.load_default()


def fit_canvas(
    im: Image.Image,
    mode: str,
    size: int | None = None,
    w: int | None = None,
    h: int | None = None,
) -> Image.Image:
    """按预设生成画布：方图居中裁切；宽约束等比缩放；固定比例。背景白。"""
    im = ImageOps.exif_transpose(im)
    if im.mode not in ("RGB", "RGBA"):
        im = im.convert("RGBA" if "A" in im.getbands() else "RGB")

    if mode == "square":
        assert size
        side = size
        src = im.convert("RGBA")
        ratio = max(side / src.width, side / src.height)
        nw, nh = int(src.width * ratio + 0.5), int(src.height * ratio + 0.5)
        src = src.resize((max(nw, 1), max(nh, 1)), Image.Resampling.LANCZOS)
        left = (src.width - side) // 2
        top = (src.height - side) // 2
        src = src.crop((left, top, left + side, top + side))
        bg = Image.new("RGB", (side, side), (255, 255, 255))
        bg.paste(src, (0, 0), src)
        return bg

    if mode == "width":
        assert size
        nh = max(1, int(im.height * (size / im.width) + 0.5))
        return im.convert("RGB").resize((size, nh), Image.Resampling.LANCZOS)

    if mode == "ratio":
        assert w and h
        src = im.convert("RGBA")
        ratio = max(w / src.width, h / src.height)
        nw, nh = int(src.width * ratio + 0.5), int(src.height * ratio + 0.5)
        src = src.resize((max(nw, 1), max(nh, 1)), Image.Resampling.LANCZOS)
        left = (src.width - w) // 2
        top = (src.height - h) // 2
        src = src.crop((left, top, left + w, top + h))
        bg = Image.new("RGB", (w, h), (255, 255, 255))
        bg.paste(src, (0, 0), src)
        return bg

    raise ValueError(f"未知 mode: {mode}")


def _position_xy(
    base_w: int,
    base_h: int,
    box_w: int,
    box_h: int,
    position: str,
    margin: int,
) -> tuple[int, int]:
    pos_map = {
        "bottom-right": (base_w - box_w - margin, base_h - box_h - margin),
        "bottom-left": (margin, base_h - box_h - margin),
        "top-right": (base_w - box_w - margin, margin),
        "top-left": (margin, margin),
        "center": ((base_w - box_w) // 2, (base_h - box_h) // 2),
    }
    return pos_map.get(position, pos_map["bottom-right"])


def apply_text_watermark(
    im: Image.Image,
    text: str,
    opacity: int = 140,
    position: str = "bottom-right",
    tile: bool = False,
) -> Image.Image:
    if not text:
        return im
    base = im.convert("RGBA")
    overlay = Image.new("RGBA", base.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay)
    font_size = max(14, base.width // 36)
    font = pick_font(font_size)
    bbox = draw.textbbox((0, 0), text, font=font)
    tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
    margin = max(8, base.width // 80)
    alpha = max(20, min(255, opacity))

    if tile:
        gap_x = max(tw + 40, base.width // 5)
        gap_y = max(th + 40, base.height // 6)
        for y in range(margin, base.height, gap_y):
            for x in range(margin, base.width, gap_x):
                draw.text((x, y), text, fill=(255, 255, 255, alpha), font=font)
                draw.text((x + 1, y + 1), text, fill=(30, 30, 30, min(255, alpha + 40)), font=font)
    else:
        xy = _position_xy(base.width, base.height, tw, th, position, margin)
        pad = 4
        draw.rectangle(
            [xy[0] - pad, xy[1] - pad, xy[0] + tw + pad, xy[1] + th + pad],
            fill=(255, 255, 255, min(200, alpha + 40)),
        )
        draw.text(xy, text, fill=(30, 30, 30, min(255, alpha + 80)), font=font)

    return Image.alpha_composite(base, overlay).convert("RGB")


def apply_logo_watermark(
    im: Image.Image,
    logo_path: Path,
    scale: float = 0.18,
    opacity: int = 180,
    position: str = "bottom-right",
) -> Image.Image:
    """叠加透明 PNG Logo；scale 相对主图宽比例。"""
    if not logo_path or not logo_path.is_file():
        raise FileNotFoundError(f"Logo 文件不存在: {logo_path}")
    base = im.convert("RGBA")
    with Image.open(logo_path) as logo_raw:
        logo = ImageOps.exif_transpose(logo_raw).convert("RGBA")
    target_w = max(16, int(base.width * max(0.02, min(0.8, scale))))
    ratio = target_w / logo.width
    target_h = max(16, int(logo.height * ratio))
    logo = logo.resize((target_w, target_h), Image.Resampling.LANCZOS)

    # 调透明度
    if opacity < 255:
        r, g, b, a = logo.split()
        a = a.point(lambda p: int(p * (max(0, min(255, opacity)) / 255.0)))
        logo = Image.merge("RGBA", (r, g, b, a))

    margin = max(8, base.width // 80)
    xy = _position_xy(base.width, base.height, logo.width, logo.height, position, margin)
    overlay = Image.new("RGBA", base.size, (0, 0, 0, 0))
    overlay.paste(logo, xy, logo)
    return Image.alpha_composite(base, overlay).convert("RGB")


def sanitize_token(s: str) -> str:
    s = re.sub(r"[\\/:*?\"<>|]+", "_", s)
    s = re.sub(r"\s+", "_", s.strip())
    return s[:80] if s else "img"


def render_name(
    pattern: str,
    *,
    stem: str,
    preset: str,
    label: str,
    w: int,
    h: int,
    index: int,
    quality: int,
    now: datetime,
) -> str:
    mapping = {
        "stem": sanitize_token(stem),
        "preset": sanitize_token(preset),
        "label": sanitize_token(label),
        "w": str(w),
        "h": str(h),
        "index": f"{index:03d}",
        "date": now.strftime("%Y%m%d"),
        "time": now.strftime("%H%M%S"),
        "quality": str(quality),
    }
    out = pattern
    for k, v in mapping.items():
        out = out.replace("{" + k + "}", v)
    out = sanitize_token(out)
    return out or "out"


def save_with_target_kb(
    im: Image.Image,
    dest: Path,
    fmt: str,
    quality: int,
    max_kb: int | None,
) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    fmt_u = fmt.upper()
    if fmt_u == "JPG":
        fmt_u = "JPEG"
    if max_kb is None or fmt_u not in ("JPEG", "WEBP"):
        params: dict = {}
        if fmt_u in ("JPEG", "WEBP"):
            params["quality"] = quality
            params["optimize"] = True
        if fmt_u == "JPEG":
            im.convert("RGB").save(dest, format=fmt_u, **params)
        else:
            im.save(dest, format=fmt_u, **params)
        return

    lo, hi = 40, min(95, quality)
    best = quality
    for _ in range(8):
        mid = (lo + hi) // 2
        im.convert("RGB").save(dest, format=fmt_u, quality=mid, optimize=True)
        size_kb = dest.stat().st_size / 1024
        best = mid
        if size_kb > max_kb:
            hi = mid - 1
        else:
            lo = mid + 1
    im.convert("RGB").save(dest, format=fmt_u, quality=best, optimize=True)


def process_one(
    src: Path,
    out_root: Path,
    presets: dict,
    quality: int,
    max_kb: int | None,
    fmt: str,
    watermark: str,
    wm_pos: str,
    wm_opacity: int,
    wm_tile: bool,
    logo: Path | None,
    logo_scale: float,
    logo_opacity: int,
    name_pattern: str,
    flat: bool,
    index: int,
    now: datetime,
) -> JobResult:
    outs: list[Path] = []
    with Image.open(src) as raw:
        for key, cfg in presets.items():
            mode = cfg.get("mode", "square")
            label = cfg.get("label", key)
            fitted = fit_canvas(
                raw,
                mode=mode,
                size=cfg.get("size"),
                w=cfg.get("w"),
                h=cfg.get("h"),
            )
            if watermark:
                fitted = apply_text_watermark(
                    fitted, watermark, opacity=wm_opacity, position=wm_pos, tile=wm_tile
                )
            if logo:
                fitted = apply_logo_watermark(
                    fitted, logo, scale=logo_scale, opacity=logo_opacity, position=wm_pos
                )
            stem_name = render_name(
                name_pattern,
                stem=src.stem,
                preset=key,
                label=label,
                w=fitted.width,
                h=fitted.height,
                index=index,
                quality=quality,
                now=now,
            )
            ext = ".jpg" if fmt.lower() in ("jpg", "jpeg") else f".{fmt.lower()}"
            if flat:
                dest = out_root / f"{stem_name}{ext}"
            else:
                dest = out_root / key / f"{stem_name}{ext}"
            # 重名时追加序号，避免覆盖
            if dest.exists():
                n = 2
                while True:
                    alt = dest.with_name(f"{dest.stem}_{n}{dest.suffix}")
                    if not alt.exists():
                        dest = alt
                        break
                    n += 1
            save_with_target_kb(fitted, dest, fmt, quality, max_kb)
            outs.append(dest)
    return JobResult(src=src, outs=outs, note="ok")


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(
        description="电商主图本地批处理：压图 + 多尺寸 + 文字/Logo 水印 + 导出命名（不上传）"
    )
    ap.add_argument("input_dir", type=Path, help="源图文件夹")
    ap.add_argument("-o", "--out", type=Path, default=Path("out"), help="输出根目录（默认 out/）")
    ap.add_argument("--presets", type=Path, default=None, help="自定义预设 JSON")
    ap.add_argument("--only", nargs="*", default=None, help="只跑指定预设 key")
    ap.add_argument("--quality", type=int, default=82, help="JPEG/WebP 质量 1-95（默认 82）")
    ap.add_argument("--max-kb", type=int, default=None, help="单张目标体积上限 KB")
    ap.add_argument("--format", choices=["jpg", "png", "webp"], default="jpg", help="输出格式")
    ap.add_argument("--watermark", default="", help="文字水印（空=不加）")
    ap.add_argument(
        "--wm-pos",
        default="bottom-right",
        choices=["bottom-right", "bottom-left", "top-right", "top-left", "center"],
    )
    ap.add_argument("--wm-opacity", type=int, default=140, help="文字水印不透明度 0-255")
    ap.add_argument("--wm-tile", action="store_true", help="文字水印平铺铺满（防盗更强）")
    ap.add_argument("--logo", type=Path, default=None, help="PNG Logo 水印路径（可选）")
    ap.add_argument("--logo-scale", type=float, default=0.18, help="Logo 相对主图宽度比例（默认 0.18）")
    ap.add_argument("--logo-opacity", type=int, default=180, help="Logo 不透明度 0-255")
    ap.add_argument(
        "--name-pattern",
        default=DEFAULT_NAME_PATTERN,
        help="导出文件名模板，可用 {stem}{preset}{label}{w}{h}{index}{date}{time}{quality}",
    )
    ap.add_argument("--flat", action="store_true", help="所有导出平铺在 out/，不分子文件夹")
    ap.add_argument("--recursive", action="store_true", help="递归子目录")
    # 兼容旧包参数（无实际差异：命名由 --name-pattern 控制）
    ap.add_argument("--keep-name", action="store_true", help="兼容旧版：等价于 --name-pattern {stem}")
    args = ap.parse_args(argv)

    if not args.input_dir.is_dir():
        print(f"找不到输入目录: {args.input_dir}", file=sys.stderr)
        return 2

    presets = load_presets(args.presets)
    if args.only:
        missing = [k for k in args.only if k not in presets]
        if missing:
            print(f"未知预设: {missing}", file=sys.stderr)
            return 2
        presets = {k: presets[k] for k in args.only}

    if args.logo and not args.logo.is_file():
        print(f"Logo 不存在: {args.logo}", file=sys.stderr)
        return 2

    images = list(iter_images(args.input_dir, args.recursive))
    if not images:
        print("未找到 jpg/png/webp/bmp 图片", file=sys.stderr)
        return 1

    name_pattern = "{stem}" if args.keep_name else args.name_pattern
    now = datetime.now()
    args.out.mkdir(parents=True, exist_ok=True)

    ok = 0
    for i, src in enumerate(images, start=1):
        try:
            r = process_one(
                src,
                args.out,
                presets,
                args.quality,
                args.max_kb,
                args.format,
                args.watermark,
                args.wm_pos,
                args.wm_opacity,
                args.wm_tile,
                args.logo,
                args.logo_scale,
                args.logo_opacity,
                name_pattern,
                args.flat,
                i,
                now,
            )
            ok += 1
            print(f"[OK] {src.name} → {len(r.outs)} 张")
        except Exception as e:  # noqa: BLE001
            print(f"[FAIL] {src}: {e}", file=sys.stderr)

    print(f"完成：{ok}/{len(images)} · 输出目录 {args.out.resolve()}")
    print("说明：源文件夹内原图未修改；文字与 Logo 水印均为可选。")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
