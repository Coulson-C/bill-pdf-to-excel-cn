#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 -m venv .venv
# shellcheck disable=SC1091
source .venv/bin/activate
pip install -r requirements.txt
python scripts/generate_samples.py
python image_batch.py samples -o out \
  --presets presets/ecommerce_cn.json \
  --only taobao_800 detail_750 \
  --quality 80 --max-kb 300 \
  --watermark "仅供店铺演示" --wm-pos bottom-right \
  --logo assets/demo_logo.png --logo-scale 0.22 --logo-opacity 200 \
  --name-pattern "{stem}_{preset}_{w}x{h}"
echo "完成：查看 out/；samples/ 与 assets/ 原文件未改动。"
