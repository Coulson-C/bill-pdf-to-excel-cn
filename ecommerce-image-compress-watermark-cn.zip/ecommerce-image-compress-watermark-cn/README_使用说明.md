# 电商主图本地批压 + 防盗水印（升级包）

一张源图 → 淘宝 / 拼多多 / 京东 / 抖店常见尺寸；可选压到目标 KB；**批量文字水印和/或 PNG Logo**；**自定义导出命名**。  
**图在本机 CPU 处理，不上传、不登录。不做 AI 超分、不承诺商用抠图。**

版本：burn-night-watermark-2026-10-31 · 建议标价 **¥49** 买断（相对「纯压图」SKU 的升级/替代款）

---

## 和「纯压图」旧包差在哪

| | 旧包 `ecommerce-image-batch-compress-cn` | **本包（升级）** |
|--|--|--|
| 多平台尺寸 + 压图/目标 KB | ✅ | ✅ |
| 文字水印 | 基础 | ✅ 位置/透明度/**平铺** |
| PNG Logo 叠加 | ❌ | ✅ 比例/透明度/位置 |
| 导出命名模板 | 固定 stem | ✅ `{stem}_{preset}_{w}x{h}` 等 |
| 平铺输出 `--flat` | ❌ | ✅ |

上架建议见同目录 `PRODUCT.md`：**推荐新 SKU ¥49 替代旧压图上架文案**；旧包可降为 ¥39 引流或下架。

---

## 包内有什么

| 内容 | 说明 |
|------|------|
| `image_batch.py` | 主程序 |
| `presets/ecommerce_cn.json` | 中文电商尺寸预设 |
| `assets/demo_logo.png` | 演示用半透明 Logo（一键演示时生成） |
| `requirements.txt` | 仅需 Pillow |
| `一键演示.sh` / `.bat` | 生成样例并跑通 |
| `scripts/generate_samples.py` | 色块演示图 + Logo |
| `01_免责声明.txt` | 请先阅读 |
| `PRODUCT.md` | 与旧 SKU 关系 / 上架建议 |
| `taobao-listing-paste.txt` | 淘宝粘贴文案 |

---

## 环境

- Windows 10/11、macOS 或 Linux
- Python **3.10+**
- 本地 CPU；无需独立显卡；无需账号登录

---

## 安装与一键演示

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
source .venv/bin/activate
pip install -r requirements.txt
python scripts/generate_samples.py
python image_batch.py samples -o out \
  --presets presets/ecommerce_cn.json \
  --only taobao_800 detail_750 \
  --quality 80 --max-kb 300 \
  --watermark "仅供店铺演示" \
  --logo assets/demo_logo.png --logo-scale 0.22 \
  --name-pattern "{stem}_{preset}_{w}x{h}"
```

或运行 `一键演示.bat` / `bash 一键演示.sh`。  
打开 `out/taobao_800/` 等；**`samples/` 原图不会被改写**。

---

## 处理你自己的主图

1. 把 JPG/PNG/WebP 放进一个文件夹。  
2. 准备可选的透明底 PNG Logo（店标）。  
3. 运行示例：

```bash
python image_batch.py 你的图片文件夹 -o out \
  --presets presets/ecommerce_cn.json \
  --quality 82 --max-kb 500 \
  --watermark "你的店名" --wm-pos bottom-right \
  --logo 你的店标.png --logo-scale 0.15 --logo-opacity 200 \
  --name-pattern "{date}_{stem}_{preset}"
```

### 常用参数

| 参数 | 含义 |
|------|------|
| `--only taobao_800 detail_750` | 只导出部分预设 |
| `--format webp` | 输出 WebP |
| `--max-kb 300` | 逼近单张体积上限（JPEG/WebP） |
| `--watermark "文字"` | 文字水印 |
| `--wm-tile` | 文字平铺防盗 |
| `--wm-pos center` | 水印位置 |
| `--wm-opacity 140` | 文字透明度 0–255 |
| `--logo path.png` | PNG Logo 路径 |
| `--logo-scale 0.18` | Logo 约占主图宽度比例 |
| `--logo-opacity 180` | Logo 透明度 |
| `--name-pattern "..."` | 导出文件名模板 |
| `--flat` | 全部平铺到 `out/`，不分子文件夹 |
| `--recursive` | 含子目录 |
| `--keep-name` | 兼容旧版：文件名仅用源名 |

### 命名占位符

`{stem}` `{preset}` `{label}` `{w}` `{h}` `{index}` `{date}` `{time}` `{quality}`

示例：

- `{stem}_{preset}_{w}x{h}` → `demo_a_taobao_800_800x800.jpg`
- `{date}_{stem}` → `20261031_demo_a.jpg`
- `{index}_{stem}_{preset}` → `001_demo_a_taobao_800.jpg`

自定义预设：复制 `presets/ecommerce_cn.json` 改边长后 `--presets 你的.json`。

---

## 能力边界

**能做：** 批量缩放/方图裁切、质量或目标 KB 压缩、多文件夹导出、文字/Logo 水印、自定义命名、保留原图。  
**不做：** GPU/AI 超分、自动抠图、批量修图美颜、云端同步、替你过平台审核、版权登记。  
平台对主图规则可能变更；导出后请人工目检再上传。

---

## 免责（摘要）

见 `01_免责声明.txt`。数字商品发出后除文件损坏核实补发外，主观不满意一般不退（以销售渠道规则为准）。请仅处理您有权使用的图片与 Logo。
