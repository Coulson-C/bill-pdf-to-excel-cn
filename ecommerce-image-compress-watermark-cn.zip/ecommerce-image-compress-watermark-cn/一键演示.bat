@echo off
chcp 65001 >nul
cd /d "%~dp0"
python -m venv .venv
call .venv\Scripts\activate.bat
pip install -r requirements.txt
python scripts\generate_samples.py
python image_batch.py samples -o out --presets presets\ecommerce_cn.json --only taobao_800 detail_750 --quality 80 --max-kb 300 --watermark "仅供店铺演示" --wm-pos bottom-right --logo assets\demo_logo.png --logo-scale 0.22 --logo-opacity 200 --name-pattern "{stem}_{preset}_{w}x{h}"
echo Done. See out\ . Originals untouched.
pause
