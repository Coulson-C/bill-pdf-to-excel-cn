#!/usr/bin/env python3
"""生成演示主图 + 半透明 PNG Logo（非商品实拍）。"""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
SAMPLES = ROOT / "samples"
ASSETS = ROOT / "assets"
SAMPLES.mkdir(parents=True, exist_ok=True)
ASSETS.mkdir(parents=True, exist_ok=True)


def font(size: int):
    for fp in (
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/opentype/noto/NotoSerifCJK-Regular.ttc",
    ):
        try:
            return ImageFont.truetype(fp, size)
        except OSError:
            continue
    return ImageFont.load_default()


def make(name: str, size: tuple[int, int], color: tuple[int, int, int], text: str) -> None:
    im = Image.new("RGB", size, color)
    d = ImageDraw.Draw(im)
    d.text((40, size[1] // 2 - 20), text, fill=(255, 255, 255), font=font(36))
    im.save(SAMPLES / name, quality=92)


def make_logo() -> None:
    # 半透明圆角感 Logo：白底字 + alpha
    w, h = 320, 120
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    d.rounded_rectangle([4, 4, w - 5, h - 5], radius=16, fill=(20, 90, 180, 200))
    d.text((28, 36), "DEMO SHOP", fill=(255, 255, 255, 230), font=font(32))
    im.save(ASSETS / "demo_logo.png")


make("demo_product_a.jpg", (1600, 1200), (40, 110, 180), "DEMO A 1600x1200")
make("demo_product_b.png", (1000, 1000), (180, 90, 40), "DEMO B 1000 square")
make("demo_detail_long.jpg", (900, 1800), (60, 140, 80), "DEMO DETAIL tall")
make_logo()
print("samples ->", SAMPLES)
print("logo ->", ASSETS / "demo_logo.png")
